"""Interior-only real Fourier-Galerkin RK4 for odd periodic velocity fields.

Convention: u(x) = sum_k i*a[k] exp(i*k.x), viscosity = 1.  The real array
a obeys a[-k] = -a[k] for real odd fields.  Positive and negative nonzero
modes are stored.  This is a numerical trajectory generator, not a proof.

Only interior pair sums are needed to evolve a Galerkin trajectory.  A
separate residual certifier MUST retain all exterior nonlinear modes.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


class OptimizedGalerkin:
    """Real-odd Galerkin system with precomputed interior convolution pairs."""

    def __init__(self, cutoff: int):
        if isinstance(cutoff, (bool, np.bool_)) or int(cutoff) != cutoff or cutoff < 1:
            raise ValueError("cutoff must be a positive integer")
        self.cutoff = cutoff = int(cutoff)
        self.modes = np.array(
            [(x, y, z) for x in range(-cutoff, cutoff + 1)
             for y in range(-cutoff, cutoff + 1)
             for z in range(-cutoff, cutoff + 1)
             if 0 < x*x + y*y + z*z <= cutoff*cutoff], dtype=np.int64)
        self.k2 = np.sum(self.modes*self.modes, axis=1)
        self.inverse_k2 = 1.0/self.k2
        self.index = {tuple(k): j for j, k in enumerate(self.modes)}
        self.negative = np.array([self.index[tuple(-k)] for k in self.modes])
        self.mode_count = m = len(self.modes)
        self.full_pair_count = m*m

        # Build destinations once, filter before projection/accumulation, and
        # use an integer lattice lookup instead of sorting all output modes.
        destinations = self.modes[:, None, :] + self.modes[None, :, :]
        destination_k2 = np.sum(destinations*destinations, axis=2)
        self.p, self.q = np.nonzero((destination_k2 > 0)
                                   & (destination_k2 <= cutoff*cutoff))
        retained = destinations[self.p, self.q]
        lattice = np.full((2*cutoff + 1,)*3, -1, dtype=np.int64)
        lattice[tuple((self.modes + cutoff).T)] = np.arange(m)
        self.output_index = lattice[tuple((retained + cutoff).T)]
        self.q_modes = self.modes[self.q]
        self.pair_count = len(self.p)

    def rhs(self, a: np.ndarray) -> np.ndarray:
        """Return real a' = -|k|² a + P_k sum_(p+q=k) (a_p.q) a_q.

        a must have shape (mode_count, 3), be real, and represent an odd,
        divergence-free field.  Conjugacy and divergence are validated by
        tests/the caller rather than being silently repaired at every stage.
        """
        if np.iscomplexobj(a):
            raise ValueError("rhs expects real imaginary Fourier coefficients a")
        if a.shape != (self.mode_count, 3):
            raise ValueError("incorrect coefficient array shape")
        ap = a[self.p]
        dot = np.einsum("ij,ij->i", ap, self.q_modes)
        terms = dot[:, None]*a[self.q]
        convolution = np.empty_like(a, dtype=np.float64)
        for component in range(3):
            convolution[:, component] = np.bincount(
                self.output_index, weights=terms[:, component],
                minlength=self.mode_count)
        pressure = np.einsum("ij,ij->i", convolution, self.modes)*self.inverse_k2
        convolution -= self.modes*pressure[:, None]
        return convolution - self.k2[:, None]*a

    def initial(self, kind: str = "W", perturbation: float = 0.0) -> np.ndarray:
        """Real a for W=(sin z,sin x,sin y) or shear=(sin y,0,0)."""
        if kind not in ("W", "shear"):
            raise ValueError("initial kind must be W or shear")
        if not np.isfinite(perturbation):
            raise ValueError("perturbation must be finite")
        a = np.zeros((self.mode_count, 3))
        components = [((0, 1, 0), 0, 1.0)] if kind == "shear" else [
            ((0, 0, 1), 0, 1.0), ((1, 0, 0), 1, 1.0),
            ((0, 1, 0), 2, 1.0)]
        if kind == "W" and perturbation:
            components.append(((0, 1, 0), 0, perturbation))
        for k, component, amplitude in components:
            a[self.index[k], component] -= 0.5*amplitude
            a[self.index[tuple(-np.array(k))], component] += 0.5*amplitude
        return a

    def integrate(self, final_time: float, dt: float, kind: str = "W",
                  perturbation: float = 0.0) -> tuple[np.ndarray, np.ndarray]:
        """Return endpoint times and complex uhat trajectory, as old solver."""
        if not np.isfinite(final_time) or not np.isfinite(dt) or final_time <= 0 or dt <= 0:
            raise ValueError("final_time and dt must be positive finite numbers")
        steps = int(round(final_time/dt))
        if steps < 1 or not np.isclose(steps*dt, final_time, rtol=0, atol=1e-14):
            raise ValueError("final_time must be an integer multiple of dt")
        times = np.arange(steps+1)*dt
        trajectory = np.empty((steps+1, self.mode_count, 3))
        trajectory[0] = self.initial(kind, perturbation)
        for j in range(steps):
            a = trajectory[j]
            k1 = self.rhs(a)
            k2 = self.rhs(a + dt*k1/2)
            k3 = self.rhs(a + dt*k2/2)
            k4 = self.rhs(a + dt*k3)
            trajectory[j+1] = a + dt*(k1+2*k2+2*k3+k4)/6
        return times, 1j*trajectory


def save_trajectory(path: Path, system: OptimizedGalerkin, times: np.ndarray,
                    trajectory: np.ndarray) -> None:
    """Write the existing certifier-compatible NPZ interface."""
    np.savez_compressed(path, times=times, modes=system.modes,
                        uhat_real=trajectory.real, uhat_imag=trajectory.imag,
                        cutoff=system.cutoff, viscosity=1.0,
                        convention="u(x)=sum_k uhat_k exp(i k.x)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cutoff", type=int, default=3)
    parser.add_argument("--dt", type=float, default=1/128)
    parser.add_argument("--time", type=float, default=0.25)
    parser.add_argument("--initial", choices=["W", "shear"], default="W")
    parser.add_argument("--perturbation", type=float, default=0.0)
    parser.add_argument("--output", type=Path, default=Path("optimized_trajectory.npz"))
    args = parser.parse_args()
    system = OptimizedGalerkin(args.cutoff)
    times, trajectory = system.integrate(args.time, args.dt, args.initial,
                                        args.perturbation)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    save_trajectory(args.output, system, times, trajectory)
    print(json.dumps({"status": "NUMERICAL_TRAJECTORY_NOT_CERTIFICATE",
                      "cutoff": system.cutoff, "modes": system.mode_count,
                      "interior_ordered_pairs": system.pair_count,
                      "all_ordered_pairs": system.full_pair_count,
                      "steps": len(times)-1, "time": args.time,
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
