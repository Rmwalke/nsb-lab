"""Same tolerance, same-session cold timing: w2, optimized RK4, original RK4.

Six complete trials per method with balanced cyclic order. Method setup,
generation, serialization and unchanged full residual certification included.
Python imports/startup excluded. Numerical trajectories are newly generated
in each trial, not reused. No old timings enter this current comparison.
"""
import json, hashlib
from pathlib import Path
from fractions import Fraction as F
from time import perf_counter
from types import SimpleNamespace
import numpy as np
from benchmark import HERE, OUT, summary
from solver import DirectGalerkin as OriginalGalerkin, save_trajectory
from optimized_solver import OptimizedGalerkin
from certify import certify
from w2_reference import spherical_modes, build_reference_basis, evaluate_reference

TARGET=F(1,200)
REPEATS=6

def main():
    data=json.loads((HERE/'benchmark-results.json').read_text())
    selected=[]
    for method in ['w2','rk4']:
        eligible=[c for c in data['cases'] if c['method']==method and F(c['finalBoundFraction'])<=TARGET]
        assert eligible,method
        selected.append(min(eligible,key=lambda c:c['generation']['medianSeconds']+c['certificate']['medianSeconds']))
    old=dict(next(c for c in selected if c['method']=='rk4'))
    old['method']='rk4_original';old['id']=old['id'].replace('rk4_','rk4_original_')
    selected.append(old)
    observations={c['id']:[] for c in selected}
    stage_samples={c['id']:{key:[] for key in ['setup','generation','serialization','certificate']} for c in selected}
    exact_values={}
    for trial in range(REPEATS):
        shift=trial%len(selected)
        for c in selected[shift:]+selected[:shift]:
            d=c['stepDenominator'];times=np.arange(d//4+1,dtype=float)/d
            start=perf_counter()
            if c['method']=='rk4':system=OptimizedGalerkin(3)
            elif c['method']=='rk4_original':system=OriginalGalerkin(3)
            else:
                modes=spherical_modes(3);basis=build_reference_basis(modes)
                system=SimpleNamespace(cutoff=3,modes=modes)
            ready=perf_counter()
            if c['method']=='w2':frames=evaluate_reference(times,2,basis)
            else:_,frames=system.integrate(.25,1/d)
            generated=perf_counter()
            path=OUT/f'target_trajectory_{c["id"]}.npz'
            save_trajectory(path,system,times,frames)
            written=perf_counter()
            report=certify(path,OUT/f'target_certificate_{c["id"]}.json')
            done=perf_counter()
            f=F(report['final_error_upper']['fraction'])
            assert f<=TARGET
            if c['method']!='rk4_original':assert f==F(c['finalBoundFraction'])
            if c['id'] in exact_values:assert f==exact_values[c['id']]
            exact_values[c['id']]=f
            observations[c['id']].append(done-start)
            for key,value in zip(['setup','generation','serialization','certificate'],
                                 [ready-start,generated-ready,written-generated,done-written]):
                stage_samples[c['id']][key].append(value)
        print(f'Balanced three-method trial {trial+1}/{REPEATS} complete',flush=True)
    import optimized_solver, solver, certify as checker, w2_reference
    result={'targetFraction':str(TARGET),'target':float(TARGET),'trials':REPEATS,
      'selection':'From the fresh 12-case optimized-baseline grid, choose the lowest generation+certificate median per w2/optimized-RK4 method with exact bound <=1/200. Also rerun original RK4 at the same RK4 resolution as a control. This is a finite-grid selection, not global optimization.',
      'measurement':'Six new cold full-pipeline trials per method in balanced cyclic order, all in one Python process: method setup, endpoint generation, compressed input write, full residual certificate read/reconstruction/calculation/report writes. Interpreter/import startup excluded.',
      'cases':[],
      'sourceHashes':{Path(p).name:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in [__file__,optimized_solver.__file__,solver.__file__,checker.__file__,w2_reference.__file__]},
      'scope':'Local implementation timings on one short-time W test. Optimized RK4 uses real-odd coefficients and interior pairs during evolution. Full residual certification is unchanged. This does not establish general superiority, true-error ordering or the paper global theorem.'}
    from benchmark import outward6
    for c in selected:
        f=exact_values[c['id']]
        result['cases'].append({'id':c['id'],'method':c['method'],'stepDenominator':c['stepDenominator'],
          'label':{'w2':'Paper formula w2','rk4':'Optimized RK4','rk4_original':'Original RK4'}[c['method']],
          'finalBound':float(f),'finalBoundFraction':str(f),'finalBoundOutward':outward6(str(f)),
          'endToEnd':summary(observations[c['id']]),
          'stages':{key:summary(values) for key,values in stage_samples[c['id']].items()}})
    (HERE/'target-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'target':float(TARGET),'trials':REPEATS,'cases':[{'method':c['method'],'bound':c['finalBound'],'median':c['endToEnd']['medianSeconds'],'range':[c['endToEnd']['minSeconds'],c['endToEnd']['maxSeconds']]} for c in result['cases']]},indent=2),flush=True)

if __name__=='__main__':main()
