# Optimized numerical RK4 baseline

`optimized_solver.py` evolves odd real velocity fields on the 2π periodic
torus, with viscosity 1 and spherical Fourier cutoff N. It uses the same
unaliased Galerkin ODE and classical RK4 steps as the earlier direct solver.
For odd fields each complex coefficient is purely imaginary: `uhat = i*a`.
This permits real arithmetic. The RHS only accumulates pairs `p+q=k` whose
destination k is retained. At N=3 this is 6,642 ordered pairs, instead of
14,884 pairs. Full exterior residuals remain necessary in the independent
certificate and are not removed from that separate computation.

API:

- `OptimizedGalerkin(N).modes`: lexicographically ordered integer triples.
- `.initial(kind='W', perturbation=0)`: real imaginary-coefficient array a.
- `.rhs(a)`: real derivative array, with shape `(mode_count, 3)`.
- `.integrate(T, dt, kind='W', perturbation=0)`: times and **complex** endpoint
  coefficients in the existing trajectory format.
- `save_trajectory(path, system, times, trajectory)`: existing certifier NPZ
  format, including both real and imaginary parts.

`W=(sin z,sin x,sin y)` and the exact decaying shear `(sin y,0,0)` are
supported. This specialized odd-field implementation does not accept general
complex coefficients for non-odd flow. The common field class and restriction
must be disclosed in any timing comparison.

Run from this directory, adjusting the original solver path if needed:

```sh
python optimized_solver.py --cutoff 3 --time 0.25 --dt 0.0078125 --output optimized_trajectory.npz
python test_optimized_solver.py --original solver.py
```

Tests compare generic odd divergence-free random fields and all trajectory
endpoints for N=2,3 and dt=1/64,1/128,1/256. They also check energy balance,
conjugacy, divergence and fourth-order convergence for exact shear. These
checks establish numerical consistency, not a PDE proof or speed advantage.
