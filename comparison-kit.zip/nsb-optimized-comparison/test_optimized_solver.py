"""Validate equivalence and structure; intentionally no speed claims."""

import importlib.util
import json
from pathlib import Path

import numpy as np

from optimized_solver import OptimizedGalerkin


def load_original(path):
    spec = importlib.util.spec_from_file_location("original_solver", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(original_path):
    original = load_original(original_path)
    report = {"status": "PASS", "rhs_comparisons": [],
              "trajectory_comparisons": [], "shear_convergence": {},
              "scope": "numerical equivalence and structural checks, not PDE certification"}
    rng = np.random.default_rng(20261019)
    for cutoff in (2, 3):
        opt, old = OptimizedGalerkin(cutoff), original.DirectGalerkin(cutoff)
        assert np.array_equal(opt.modes, old.modes)
        if cutoff == 3:
            assert opt.mode_count == 122 and opt.pair_count == 6642
        for trial in range(3):
            a = rng.normal(size=(opt.mode_count, 3))*0.05
            a = (a-a[opt.negative])/2
            a -= opt.modes*(np.sum(a*opt.modes, axis=1)/opt.k2)[:, None]
            expected = old.rhs(1j*a)
            actual = 1j*opt.rhs(a)
            difference = float(np.max(np.abs(expected-actual)))
            energy_residual = abs(float(np.sum(a*opt.rhs(a))
                                        + np.sum(opt.k2[:, None]*a*a)))
            assert difference < 2e-14
            assert energy_residual < 2e-14
            report["rhs_comparisons"].append(
                {"cutoff": cutoff, "trial": trial,
                 "maximum_coefficient_difference": difference,
                 "energy_identity_absolute_residual": energy_residual})
        for denominator in (64, 128, 256):
            times, actual = opt.integrate(0.25, 1/denominator)
            old_times, expected = old.integrate(0.25, 1/denominator)
            assert np.array_equal(times, old_times)
            difference = float(np.max(np.abs(actual-expected)))
            divergence = float(np.max(np.abs(np.sum(actual*opt.modes, axis=2))))
            reality = float(np.max(np.abs(actual[:, opt.negative]-actual.conj())))
            assert difference < 5e-15
            assert divergence < 2e-15
            assert reality < 2e-15
            report["trajectory_comparisons"].append(
                {"cutoff": cutoff, "step_denominator": denominator,
                 "maximum_coefficient_difference_over_all_endpoints": difference,
                 "maximum_divergence_coefficient": divergence,
                 "maximum_reality_defect": reality})
    system = OptimizedGalerkin(3)
    errors = []
    for denominator in (4, 8, 16):
        _, u = system.integrate(1.0, 1/denominator, "shear")
        exact = 1j*system.initial("shear")*np.exp(-1)
        errors.append(float(np.max(np.abs(u[-1]-exact))))
    ratios = [errors[0]/errors[1], errors[1]/errors[2]]
    assert all(15 < ratio < 21 for ratio in ratios)
    report["shear_convergence"] = {"step_denominators": [4, 8, 16],
                                    "maximum_coefficient_errors": errors,
                                    "refinement_error_ratios": ratios}
    for invalid in ((0.0, 1/128), (0.25, 0.0), (0.25, -1.0),
                    (float("nan"), 1/128), (0.25, 0.03)):
        try:
            system.integrate(*invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid time input accepted")
    report["invalid_time_inputs_rejected"] = 5
    report["N3_mode_count"] = system.mode_count
    report["N3_interior_ordered_pairs"] = system.pair_count
    report["N3_all_ordered_pairs"] = system.full_pair_count
    return report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("optimized_solver_validation.json"))
    args = parser.parse_args()
    report = run(args.original)
    args.output.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))
