"""Independent numerical-equivalence checks of the optimized Galerkin RHS.

This is a generator validation, not a formal proof. The literal reference
convolution below does not use pair indices from either implementation.
"""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent.parent
OUT = Path(__file__).resolve().parent
FLAT_KIT = all((OUT / name).is_file() for name in
               ("solver.py", "certify.py", "optimized_solver.py"))
ORIGINAL = OUT if FLAT_KIT else ROOT / "sites/nsb-experiment-lab/research-comparison"
OPTIMIZED = OUT if FLAT_KIT else ROOT / "work/nsb_optimized_rk4"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def literal_rhs(modes, uhat):
    """Sum every ordered p,q, then project each interior p+q explicitly."""
    index = {tuple(k): i for i, k in enumerate(modes)}
    conv = {}
    for p, a in zip(modes, uhat):
        for q, b in zip(modes, uhat):
            destination = tuple(p + q)
            if destination not in conv:
                conv[destination] = np.zeros(3, dtype=np.complex128)
            conv[destination] += 1j * np.dot(a, q) * b
    result = np.empty_like(uhat)
    for i, k in enumerate(modes):
        k2 = int(np.dot(k, k))
        value = conv.get(tuple(k), np.zeros(3, dtype=np.complex128))
        nonlinear = value - k * np.dot(k, value) / k2
        result[i] = -k2 * uhat[i] - nonlinear
    return result


def generic_odd(modes, seed=84112):
    """Real, odd, exactly-conjugate float data with projected coefficients."""
    rng = np.random.default_rng(seed)
    index = {tuple(k): i for i, k in enumerate(modes)}
    result = np.zeros((len(modes), 3), dtype=np.complex128)
    visited = set()
    for i, k in enumerate(modes):
        if i in visited:
            continue
        j = index[tuple(-k)]
        a = rng.normal(size=3) * 0.03
        a -= k * np.dot(k, a) / np.dot(k, k)
        result[i] = 1j * a
        result[j] = -1j * a
        visited.update((i, j))
    return result


def main():
    original = load("original_solver", ORIGINAL / "solver.py")
    certificate = load("original_certificate", ORIGINAL / "certify.py")
    optimized = load("optimized_solver", OPTIMIZED / "optimized_solver.py")
    klass = optimized.OptimizedGalerkin
    checks = []
    for cutoff in (2, 3):
        base, fast = original.DirectGalerkin(cutoff), klass(cutoff)
        assert np.array_equal(base.modes, fast.modes)
        for label, coefficients in (
            ("W", base.initial("W")),
            ("shear", base.initial("shear")),
            ("generic_odd_divergence_free", generic_odd(base.modes)),
        ):
            expected = literal_rhs(base.modes, coefficients)
            got = 1j * fast.rhs(coefficients.imag)
            original_got = base.rhs(coefficients)
            error = float(np.max(np.abs(got - expected)))
            old_error = float(np.max(np.abs(original_got - expected)))
            assert error < 1e-13, (cutoff, label, error)
            assert old_error < 1e-13, (cutoff, label, old_error)
            checks.append({"cutoff": cutoff, "field": label,
                           "literal_rhs_max_abs_difference": error,
                           "original_rhs_max_abs_difference": float(np.max(np.abs(got-original_got))),
                           "original_vs_literal_max_abs_difference": old_error})
    base, fast = original.DirectGalerkin(3), klass(3)
    trajectories = []
    for kind in ("W", "shear"):
        times, expected = base.integrate(.25, 1/128, kind)
        got_times, got = fast.integrate(.25, 1/128, kind)
        assert np.array_equal(times, got_times)
        error = float(np.max(np.abs(got - expected)))
        assert error < 1e-13, (kind, error)
        modes = [tuple(int(x) for x in k) for k in base.modes]
        before, d0 = certificate.reconstruct(modes, expected.real, expected.imag, 40)
        after, d1 = certificate.reconstruct(modes, got.real, got.imag, 40)
        reconstruction_equal = d0 == d1 and before == after
        assert reconstruction_equal, kind
        item = {"kind": kind, "cutoff": 3, "step_denominator": 128,
                "time": .25, "all_endpoints_max_abs_difference": error,
                "exact_rational_reconstruction_identical": reconstruction_equal}
        if kind == "shear":
            exact = np.exp(-times)[:, None, None] * base.initial("shear")
            item["analytic_shear_max_abs_difference"] = float(np.max(np.abs(got-exact)))
            assert item["analytic_shear_max_abs_difference"] < 4e-12
        trajectories.append(item)
    report = {"status": "PASS", "rhs_checks": checks,
              "trajectory_checks": trajectories,
              "certificate_scope": "Only trajectory generation is optimized. Unmodified ExactResidual constructs all input-pair sums and measures every exterior residual mode.",
              "source_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                 for path in (ORIGINAL/"solver.py", ORIGINAL/"certify.py", OPTIMIZED/"optimized_solver.py", Path(__file__))}}
    (OUT/"independent-validation.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
