# NS-B numerical trajectory generator

This new implementation generates an actual finite Fourier-Galerkin trajectory
for the unforced incompressible Navier-Stokes equations. It is not a picture
animation or a replay of archived certificate numbers. It is also **not itself a
rigorous error certificate**, a proof of the paper, a new numerical method, or an
industrial CFD benchmark.

The domain is the normalized `2π` periodic three-dimensional torus and viscosity
is `1`. The default initial field is `W=(sin z, sin x, sin y)`. These dimensionless
inputs do not describe a particular physical fluid or engineering installation.

## Conventions and numerical method

`u(x,t) = Σ_k uhat[k,t] exp(i k·x)`, with the mean-zero mode excluded. Every
nonzero integer mode satisfying `|k|²≤N²` is stored, including both signs. The
Fourier coefficients are vectors of length three.

The system advanced by classical RK4 is

`uhat'_k = -|k|² uhat_k - i P_k Σ_(p+q=k) (q·uhat_p) uhat_q`.

Convolutions use ordinary integer-vector addition and all ordered pairs. They
never use FFT wrapping or circular convolution. Leray projection is
`P_k b = b - k(k·b)/|k|²`. Floating point evaluation of this algebra is approximate.

`solver.py` implements general complex coefficients. It can return the nonlinear
term on **all** possible pair-sum modes, including modes exterior to the retained
Galerkin space. This matters when a separate certificate checks the residual
against the full PDE rather than only the finite-dimensional system.

`solver-engine.js` uses the invariant odd-real-field subspace `uhat_k=i a_k`, with
real `a_k`. It evolves the equivalent system
`a'_k=-|k|² a_k+P_k Σ_(p+q=k)(a_p·q)a_q` and provides all frames for a browser.
The UI engine is deliberately scoped to `N=2` or `3`, `dt=1/64` or `1/128`, and
`T=1/4`. It also supports the exact decaying shear regression case. This symmetry
restriction should not be generalized to arbitrary initial fields.

## Run

Python requires NumPy. The JavaScript engine has no runtime dependencies.

```sh
python solver.py --cutoff 3 --dt 0.00390625 --time 0.25 --output trajectory.npz
python validate_solver.py
node test-browser-engine.mjs
```

Each NPZ contains `times`, integer `modes`, `uhat_real`, `uhat_imag`, and convention
metadata. Trajectory arrays have shape `(number of time nodes, modes, 3)`. The
stored times are solution samples; interpolation between samples is a separate
choice whose residual must be accounted for by any rigorous certificate.

## Validation actually executed

See `solver_validation.json` and `browser_engine_validation.json` for measured
results. They include:

- Exact shear `u=(exp(-t) sin y,0,0)` and fourth-order time refinement behavior.
- The nonlinear energy cancellation identity on a generic real divergence-free
  finite Fourier field, not just the symmetric W initial field.
- Literal nested-loop convolution compared with the vectorized implementation.
- Divergence, conjugate symmetry and decaying energy throughout the W traces.
- Four Python/browser comparisons, with maximum final coefficient difference
  below `7e-18` in the recorded run.
- Empirical time-step and cutoff refinement differences at `T=1/4`.

Refinement differences are useful numerical diagnostics; **they are not proven
error bounds**. Passing these tests does not independently establish the analytic
enclosures in the preprint. A separate rational residual certificate must state
its own theorem, assumptions, spatial/time truncation treatment and exact output.

The normalized spatial L2 norm is `sqrt(Σ_k |uhat_k|²)`. The energy diagnostic is
one half its square. Hence W starts with normalized L2 `sqrt(3/2)` and energy
`3/4`; different normalizations must not be compared without conversion.
