"""Meaningful solver checks; convergence differences are NOT rigorous bounds."""
from pathlib import Path
from time import perf_counter
import json
import numpy as np
from solver import DirectGalerkin, save_trajectory


HERE = Path(__file__).resolve().parent


def a0_difference(system_a, coeff_a, system_b, coeff_b):
    modes = set(system_a.index) | set(system_b.index)
    zero = np.zeros(3, dtype=complex)
    return float(sum(np.linalg.norm(
            (coeff_a[system_a.index[k]] if k in system_a.index else zero)
            - (coeff_b[system_b.index[k]] if k in system_b.index else zero))
            for k in modes))


def main():
    started = perf_counter()
    results = {"scope": "Floating point solver validation; not rigorous PDE error bounds"}

    # One-mode shear is an exact NS solution, so this catches Fourier phase,
    # sign of viscosity, nonlinear projection, and RK4 convergence errors.
    shear = DirectGalerkin(2)
    u0 = shear.initial("shear")
    assert np.max(np.abs(shear.nonlinear_all(u0))) == 0
    errors = []
    for dt in [1/16, 1/32, 1/64]:
        times, values = shear.integrate(0.25, dt, "shear")
        error = float(np.max(np.abs(values[-1] - np.exp(-0.25)*u0)))
        errors.append({"dt": dt, "max_coefficient_error": error})
    ratios = [errors[i]["max_coefficient_error"]/errors[i+1]["max_coefficient_error"]
              for i in range(len(errors)-1)]
    assert all(15 < ratio < 18 for ratio in ratios), ratios
    results["exact_shear_RK4"] = {"errors": errors, "error_ratios": ratios}

    # Conservation identity for the nonlinear Galerkin term: energy derivative
    # must be minus the viscous dissipation, tested on generic projected real
    # fields rather than only the highly symmetric paper example.
    rng = np.random.default_rng(271828)
    s3 = DirectGalerkin(3)
    random_field = rng.normal(size=(len(s3.modes), 3))+1j*rng.normal(size=(len(s3.modes), 3))
    random_field = (random_field + np.conjugate(random_field[s3.negative]))/2
    random_field = s3.leray(random_field, s3.modes)*0.01
    random_diagnostic = s3.diagnostic(random_field)
    assert random_diagnostic["energy_identity_abs_residual"] < 1e-12
    assert random_diagnostic["max_divergence_coefficient"] < 1e-14
    assert random_diagnostic["max_reality_defect"] < 1e-14
    results["generic_field_energy_identity"] = random_diagnostic

    # Compare the vectorized direct convolution against literal nested sums at
    # a small cutoff on a non-symmetric generic field.
    small = DirectGalerkin(1)
    v = rng.normal(size=(len(small.modes), 3))+1j*rng.normal(size=(len(small.modes), 3))
    v = small.leray((v+v[small.negative].conjugate())/2, small.modes)
    explicit = np.zeros((len(small.output_modes), 3), dtype=complex)
    out_lookup = {tuple(k): i for i,k in enumerate(small.output_modes)}
    for p, kp in enumerate(small.modes):
        for q, kq in enumerate(small.modes):
            explicit[out_lookup[tuple(kp+kq)]] += 1j*np.dot(kq, v[p])*v[q]
    explicit = small.leray(explicit, small.output_modes)
    direct_error = float(np.max(np.abs(explicit-small.nonlinear_all(v))))
    assert direct_error < 1e-13
    results["direct_convolution_max_difference"] = direct_error

    final_values = {}
    snapshots = []
    for cutoff, dt in [(2, 1/64), (2, 1/256), (3, 1/256), (3, 1/512), (4, 1/256)]:
        system = DirectGalerkin(cutoff)
        run_start = perf_counter()
        times, trajectory = system.integrate(0.25, dt)
        elapsed = perf_counter()-run_start
        path = HERE/f"trajectory_N{cutoff}_dt{round(1/dt)}.npz"
        save_trajectory(path, system, times, trajectory)
        endpoint = system.diagnostic(trajectory[-1])
        energies = np.sum(np.abs(trajectory)**2, axis=(1,2))/2
        max_divergence = float(np.max(np.abs(np.sum(trajectory*system.modes[None,:,:],axis=2))))
        max_reality = float(np.max(np.abs(trajectory[:,system.negative,:]-trajectory.conjugate())))
        assert np.max(np.diff(energies)) < 1e-14
        assert max_divergence < 1e-13
        assert max_reality < 1e-13
        snapshots.append({"file": path.name, "cutoff": cutoff, "dt": dt,
                          "steps": len(times)-1, "modes": len(system.modes),
                          "seconds": elapsed, "final": endpoint,
                          "max_divergence_over_all_steps": max_divergence,
                          "max_reality_defect_over_all_steps": max_reality})
        final_values[cutoff, dt] = (system, trajectory[-1])
    results["trajectories"] = snapshots
    comparisons = {}
    for label, a, b in [("N3_dt256_vs_dt512",(3,1/256),(3,1/512)),
                       ("N2_vs_N3_dt256",(2,1/256),(3,1/256)),
                       ("N3_vs_N4_dt256",(3,1/256),(4,1/256))]:
        comparisons[label] = a0_difference(*final_values[a], *final_values[b])
    results["empirical_endpoint_A0_differences_not_bounds"] = comparisons
    results["elapsed_seconds"] = perf_counter()-started
    results["status"] = "ALL_CHECKS_PASSED"
    (HERE/"solver_validation.json").write_text(json.dumps(results, indent=2)+"\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
