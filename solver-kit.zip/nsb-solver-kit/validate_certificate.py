"""Meaningful boundary/negative checks for the exact residual implementation."""
import json
from fractions import Fraction as F
from pathlib import Path
from certify import ExactResidual, certify, exp_upper, sqrt_upper

HERE=Path(__file__).resolve().parent
checks={}
# A precisely prescribed linear-in-time shear, no numerical solver involved.
# v=(1-t)sin(y)e_x on [0,1/4]: r=-t*sin(y)e_x.
modes=[(0,-1,0),(0,1,0)]
D=8
a=[[0,0,0,4,0,0],[0,0,0,-4,0,0]]
b=[[0,0,0,3,0,0],[0,0,0,-3,0,0]]
g=ExactResidual(modes,D)
r,_=g.residual_bounds(a,b,F(1,4))
expected=[F(0),F(1,128),F(1,32)]
assert r['bernstein_l2_squared']==expected
assert r['R_exterior']==0
checks['analytic_linear_shear']={'pass':True,'bernstein_l2_squared':[str(x) for x in expected]}
# Directed root and exponential boundary checks use exact rational comparisons.
for x in [F(0),F(1,3),F(2),F(1000,7)]:
    assert sqrt_upper(x)**2 >= x
assert sqrt_upper(0)==0 and exp_upper(0)==1
assert exp_upper(F(1,100))>1+F(1,100)
checks['directed_arithmetic_boundaries']={'pass':True}
# A finite spatial cutoff actually generates exterior residual; omitting it
# would fail this test even when every retained Galerkin ODE is solved well.
base=certify(HERE/'trajectory_N3_dt128.npz')
assert any(s['nonzero_exterior_modes']>0 for s in base['step_bounds'])
assert any(F(s['R_exterior_upper']['fraction'])>0 for s in base['step_bounds'])
checks['exterior_residual_present']={'pass':True,'full_modes':base['full_residual_modes'],
                                    'interior_modes':base['interior_modes']}
# Controlled numerical bad-path test: the exact same source file plus a local
# 1/8*sin(z)e_x excursion at its midpoint has a much worse certificate.
bad=certify(HERE/'trajectory_N3_dt128.npz',tamper_amplitude=F(1,8))
e_good=F(base['final_error_upper']['fraction'])
e_bad=F(bad['final_error_upper']['fraction'])
assert e_bad>50*e_good
checks['midpoint_perturbation_detected']={'pass':True,'normal_error_upper':str(e_good),
    'perturbed_error_upper':str(e_bad),'ratio_approx':float(e_bad/e_good)}
result={'status':'PASS','checks':checks}
(HERE/'certificate_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
