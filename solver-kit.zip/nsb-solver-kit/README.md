# NS-B solver and finite-time residual checker

Prepared with AI assistance for Rushikesh Murlidhar Walke. This executable
research prototype concerns W=(sin z,sin x,sin y), viscosity 1, periodic torus,
and 0 <= t <= 1/4. See CERTIFICATE_README.md and finite_time_l2_bound.md for the
exact theorem assumptions and the object certified. It does not verify the
preprint's global theorem, novelty, or industrial advantage.

Requirements: Python 3 with NumPy. Node.js is optional for browser-engine checks.

Recheck the archived best numerical input (does not overwrite that input):

    python certify.py trajectory_N3_dt128.npz --output recomputed_certificate.json
    python validate_certificate.py
    node test-browser-engine.mjs

Generate an independent new numerical trajectory and certificate:

    python solver.py --cutoff 3 --dt 0.0078125 --time 0.25 --output new_trajectory.npz
    python certify.py new_trajectory.npz --output new_certificate.json

Additional solver tests: python validate_solver.py . That command regenerates
several numerical inputs. Their byte hashes can change even with identical
coefficients; rerun certify.py for regenerated files before comparing provenance.

All report decimals are display approximations. Exact fraction strings and
rational reconstruction files define the certified upper bounds and trajectories.
The browser may rerun floating RK4, but its new trajectory is not automatically
covered by the archived certificate. Original preprint/code provenance:
https://github.com/Rmwalke/nsb-open-certificate-check
https://doi.org/10.5281/zenodo.23429477
