import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {solve,evaluateVelocity,sampleNormalizedL2} from './solver-engine.js';

const refs=JSON.parse(readFileSync(new URL('./browser_reference.json',import.meta.url),'utf8'));
const checks=[];
for(const ref of refs){
  const start=performance.now();
  const result=solve({cutoff:ref.cutoff,stepDenominator:ref.dt_denominator,T:.25});
  const elapsed=performance.now()-start;
  if(JSON.stringify(result.modes)!==JSON.stringify(ref.modes))throw new Error('Mode order mismatch');
  const expect=ref.final_a.flat(),actual=result.frames.at(-1);
  let maxAbs=0;
  for(let i=0;i<expect.length;i++)maxAbs=Math.max(maxAbs,Math.abs(actual[i]-expect[i]));
  if(maxAbs>1e-12)throw new Error(`Python discrepancy ${maxAbs}`);
  const a0Error=Math.abs(result.diagnostics.at(-1).A0-ref.final_diagnostics.A0);
  if(a0Error>1e-12)throw new Error(`A0 discrepancy ${a0Error}`);
  const initialVelocity=evaluateVelocity(result.frames[0],result.modes,.71,1.12,2.2);
  const w=[Math.sin(2.2),Math.sin(.71),Math.sin(1.12)];
  for(let j=0;j<3;j++)if(Math.abs(initialVelocity[j]-w[j])>1e-14)throw new Error('W field reconstruction');
  const l2=sampleNormalizedL2(result.frames[0],result.modes);
  if(Math.abs(l2-Math.sqrt(1.5))>1e-14)throw new Error('Parseval normalization');
  checks.push({cutoff:ref.cutoff,stepDenominator:ref.dt_denominator,modes:result.modes.length,
    interiorPairs:result.orderedInteriorPairs,maxFinalCoefficientDifferenceFromPython:maxAbs,
    A0DifferenceFromPython:a0Error,elapsedMilliseconds:elapsed});
}
const shear=solve({cutoff:2,stepDenominator:128,T:.25,initial:'shear'});
let shearError=0;
for(let i=0;i<shear.frames[0].length;i++){
  shearError=Math.max(shearError,Math.abs(shear.frames.at(-1)[i]-Math.exp(-.25)*shear.frames[0][i]));
}
if(shearError>4e-12)throw new Error(`Shear error ${shearError}`);
const report={status:'ALL_CHECKS_PASSED',scope:'Cross-language floating solver check, not rigorous PDE error bound',
 checks,exactShearMaxCoefficientError:shearError};
writeFileSync(new URL('./browser_engine_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
