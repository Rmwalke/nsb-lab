"""Exact finite-time L2 residual bound for a reconstructed Fourier trajectory.

The floating point solver only proposes endpoint data. This program quantizes,
projects, and enforces reality with integer/rational arithmetic. It certifies the
continuous piecewise-linear reconstruction, not the internal RK4 trajectory.

For a real divergence-free reference v and residual r=v_t-Delta v+P(v.grad v),
relative energy against ANY Leray-Hopf solution u with the stated exact initial
condition gives E'=d||u-v||_2/dt <= L E + R, in the regularized/integrated sense.
Here ||.||_2^2 is the (2*pi)^(-3)-normalized integral and
L >= ||sym grad v||_{L-infinity,operator}, R >= ||r||_2.
We use E_next <= exp(L*h)*(E+h*R). All reported rigorous bounds are exact
rational upper bounds; decimals are display approximations. The analytic
relative-energy theorem remains a mathematical assumption, not a Lean proof.

Usage: python certify.py trajectory.npz --output certificate.json
Requires numpy only to decode numerical input; certified arithmetic is Python
integers and fractions. No network or external proof certificates are used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from fractions import Fraction as F
from pathlib import Path
from time import perf_counter
import numpy as np


PRECISION = 60


def frac_string(x):
    x = F(x)
    return f"{x.numerator}/{x.denominator}"


def upper_round(x, bits=PRECISION):
    x = F(x)
    if x < 0:
        raise ValueError("upper_round expects nonnegative input")
    d = 1 << bits
    n = (x.numerator*d + x.denominator-1)//x.denominator
    return F(n, d)


def sqrt_upper(x, bits=PRECISION):
    x = F(x)
    if x < 0:
        raise ValueError("negative square-root argument")
    d = 1 << bits
    n = (x.numerator*d*d + x.denominator-1)//x.denominator
    m = math.isqrt(n)
    if m*m < n:
        m += 1
    return F(m, d)


def exp_upper(x, bits=PRECISION):
    """Taylor polynomial with a geometric bound on the entire positive tail."""
    x = F(x)
    if x < 0:
        raise ValueError("exp_upper expects nonnegative input")
    degree = max(18, x.numerator//x.denominator + 2)
    term, total = F(1), F(1)
    for j in range(1, degree+1):
        term *= x/j
        total += term
    next_term = term*x/(degree+1)
    ratio = x/(degree+2)
    assert ratio < 1
    return upper_round(total+next_term/(1-ratio), bits)


def mode_norm(k):
    return sum(v*v for v in k)


def near_integer(x, denominator):
    # float.as_integer_ratio makes the input conversion exact. No floating
    # multiplication or uncertified rounding enters the reconstructed data.
    if not math.isfinite(float(x)):
        raise ValueError("nonfinite endpoint")
    a, b = float(x).as_integer_ratio()
    q, r = divmod(a*denominator, b)
    return q + (2*r >= b)


def reconstruct(modes, real, imag, bits):
    """Return exact projected endpoints, uniform integer denominator D."""
    base = 1 << bits
    multiple = math.lcm(*(mode_norm(k) for k in modes))
    denom = base*multiple
    index = {k: i for i, k in enumerate(modes)}
    result = []
    for re, im in zip(real, imag):
        endpoint = [None]*len(modes)
        for i, k in enumerate(modes):
            if endpoint[i] is not None:
                continue
            opposite = tuple(-v for v in k)
            if opposite not in index:
                raise ValueError("missing conjugate mode")
            j = index[opposite]
            # Use one representative. Its other half is explicitly conjugated.
            rv = [near_integer(x, base) for x in re[i]]
            iv = [near_integer(x, base) for x in im[i]]
            norm = mode_norm(k)
            dotr = sum(k[c]*rv[c] for c in range(3))
            doti = sum(k[c]*iv[c] for c in range(3))
            scale = multiple//norm
            rv = [(norm*rv[c]-k[c]*dotr)*scale for c in range(3)]
            iv = [(norm*iv[c]-k[c]*doti)*scale for c in range(3)]
            endpoint[i] = rv+iv
            endpoint[j] = rv+[-x for x in iv]
        for i, k in enumerate(modes):
            assert sum(k[c]*endpoint[i][c] for c in range(3)) == 0
            assert sum(k[c]*endpoint[i][c+3] for c in range(3)) == 0
            j = index[tuple(-v for v in k)]
            assert endpoint[j] == endpoint[i][:3]+[-x for x in endpoint[i][3:]]
        result.append(endpoint)
    return result, denom


class ExactResidual:
    def __init__(self, modes, denominator):
        self.modes = modes
        self.denominator = denominator
        all_outputs = set(modes)
        all_outputs.update(tuple(p[c]+q[c] for c in range(3))
                           for p in modes for q in modes)
        self.outputs = sorted(all_outputs)
        self.out_index = {k: i for i, k in enumerate(self.outputs)}
        self.interior = {self.out_index[k]: i for i, k in enumerate(modes)}
        self.k2 = [mode_norm(k) for k in self.outputs]
        self.multiple = math.lcm(*(n for n in self.k2 if n))
        self.pairs = [[self.out_index[tuple(p[c]+q[c] for c in range(3))]
                       for q in modes] for p in modes]
        self.zero = self.out_index[(0, 0, 0)]

    def nonlinear(self, coefficients):
        """P((v.grad)v): integer numerator, denominator D^2*multiple."""
        conv = [[0]*6 for _ in self.outputs]
        active = [i for i, a in enumerate(coefficients) if any(a)]
        for p in active:
            a = coefficients[p]
            row = self.pairs[p]
            for q in active:
                k = self.modes[q]
                dr = k[0]*a[0]+k[1]*a[1]+k[2]*a[2]
                di = k[0]*a[3]+k[1]*a[4]+k[2]*a[5]
                if not (dr or di):
                    continue
                b, out = coefficients[q], conv[row[q]]
                for c in range(3):
                    out[c] -= dr*b[c+3]+di*b[c]
                    out[c+3] += dr*b[c]-di*b[c+3]
        if any(conv[self.zero]):
            raise ArithmeticError("nonzero mean convection for divergence-free data")
        for i, (k, norm) in enumerate(zip(self.outputs, self.k2)):
            if not norm:
                continue
            a = conv[i]
            dr = sum(k[c]*a[c] for c in range(3))
            di = sum(k[c]*a[c+3] for c in range(3))
            scale = self.multiple//norm
            conv[i] = [(norm*a[c]-k[c]*dr)*scale for c in range(3)]+[
                (norm*a[c+3]-k[c]*di)*scale for c in range(3)]
        return conv

    def strain_upper(self, endpoint):
        # Exact divergence freedom gives ||sym(i*a tensor k)||_F^2
        # = |k|^2 |a|^2 / 2, including complex Hermitian modulus.
        return sum((sqrt_upper(F(mode_norm(k)*sum(x*x for x in a),
                                 2*self.denominator**2))
                    for k, a in zip(self.modes, endpoint)), F(0))

    def residual_bounds(self, a, b, h, na=None, nb=None):
        """Bound a quadratic-in-time residual over the ENTIRE closed step.

        Bernstein vectors B0,B1,B2 satisfy r(s)=(1-s)^2 B0+
        2s(1-s)B1+s^2 B2. A Hilbert norm is <=max_j ||Bj||.
        Full pair sums include every nonlinear exterior (truncation) mode.
        """
        na = self.nonlinear(a) if na is None else na
        nb = self.nonlinear(b) if nb is None else nb
        combined = [[x+y for x,y in zip(aa, bb)] for aa,bb in zip(a,b)]
        ns = self.nonlinear(combined)
        D, J = self.denominator, self.multiple
        hn, hd = h.numerator, h.denominator
        residual_denominator = 2*D*D*J*hn
        norms, interior_norms, exterior_norms = [0]*3, [0]*3, [0]*3
        nonzero_exterior = set()
        for i, k in enumerate(self.outputs):
            vals = [[2*hn*x for x in na[i]],
                    [hn*(x-y-z) for x,y,z in zip(ns[i],na[i],nb[i])],
                    [2*hn*x for x in nb[i]]]
            if i in self.interior:
                ai, bi = a[self.interior[i]], b[self.interior[i]]
                norm = self.k2[i]
                for c in range(6):
                    derivative = 2*D*J*hd*(bi[c]-ai[c])
                    vals[0][c] += derivative + 2*D*J*hn*norm*ai[c]
                    vals[1][c] += derivative + D*J*hn*norm*(ai[c]+bi[c])
                    vals[2][c] += derivative + 2*D*J*hn*norm*bi[c]
            elif any(x for block in vals for x in block):
                nonzero_exterior.add(i)
            for j in range(3):
                value = sum(x*x for x in vals[j])
                norms[j] += value
                if i in self.interior:
                    interior_norms[j] += value
                else:
                    exterior_norms[j] += value
        den2 = residual_denominator**2
        full_sq = max(norms)
        inner_sq, outer_sq = max(interior_norms), max(exterior_norms)
        return {
            'R': sqrt_upper(F(full_sq, den2)),
            'R_interior': sqrt_upper(F(inner_sq, den2)),
            'R_exterior': sqrt_upper(F(outer_sq, den2)),
            'bernstein_l2_squared': [F(x, den2) for x in norms],
            'nonzero_exterior_modes': len(nonzero_exterior),
        }, nb


def initial_exact(modes, kind='W', perturbation=F(0)):
    result = [[F(0)]*6 for _ in modes]
    index = {k:i for i,k in enumerate(modes)}
    specs = [((0,1,0),0,F(1))] if kind == 'shear' else [
        ((0,0,1),0,F(1)), ((1,0,0),1,F(1)), ((0,1,0),2,F(1))]
    if kind == 'W' and perturbation:
        specs.append(((0,1,0),0,perturbation))
    for k, c, value in specs:
        if k not in index or tuple(-v for v in k) not in index:
            raise ValueError('initial target mode missing')
        result[index[k]][c+3] -= value/2
        result[index[tuple(-v for v in k)]][c+3] += value/2
    return result


def rational_view(x):
    return {'fraction': frac_string(x), 'decimal_approx': float(x)}


def certify(path: Path, output: Path|None=None, bits=40, kind='W',
            perturbation=F(0), tamper_amplitude=F(0)):
    started = perf_counter()
    if kind == 'shear' and perturbation:
        raise ValueError('shear initial data does not take a perturbation parameter')
    with np.load(path, allow_pickle=False) as data:
        modes = [tuple(int(x) for x in row) for row in data['modes']]
        times = [F(float(x)) for x in data['times']]
        real, imag = data['uhat_real'], data['uhat_imag']
        if float(data['viscosity']) != 1:
            raise ValueError('this theorem implementation requires viscosity=1')
        if len(modes) != len(set(modes)) or any(not mode_norm(k) for k in modes):
            raise ValueError('modes must be unique and nonzero')
        if real.shape != imag.shape or real.shape != (len(times),len(modes),3):
            raise ValueError('coefficient shape mismatch')
        if len(times) < 2 or times[0] != 0 or any(b <= a for a,b in zip(times,times[1:])):
            raise ValueError('times must increase strictly from zero')
        endpoints, D = reconstruct(modes,real,imag,bits)
    if tamper_amplitude:
        # Controlled sensitivity check: add one exactly divergence-free real
        # Fourier sine perturbation at the middle endpoint, leaving target u0.
        i, j = modes.index((0,0,1)), modes.index((0,0,-1))
        delta = tamper_amplitude*D/2
        if delta.denominator != 1:
            raise ValueError('tamper amplitude must fit endpoint grid')
        mid = len(endpoints)//2
        endpoints[mid][i][3] -= delta.numerator
        endpoints[mid][j][3] += delta.numerator
    geometry = ExactResidual(modes,D)
    target = initial_exact(modes,kind,perturbation)
    E0sq = sum(((F(a,D)-b)**2 for ar,br in zip(endpoints[0],target)
                for a,b in zip(ar,br)), F(0))
    E = sqrt_upper(E0sq)
    canonical = json.dumps({'modes':modes,'times':[frac_string(t) for t in times],
                            'denominator':str(D),'endpoints':endpoints},
                           separators=(',',':')).encode()
    endpoint_sha = hashlib.sha256(canonical).hexdigest()
    Ls = [geometry.strain_upper(a) for a in endpoints]
    na = geometry.nonlinear(endpoints[0])
    rows = []
    for step,(a,b,ta,tb) in enumerate(zip(endpoints,endpoints[1:],times,times[1:])):
        h = tb-ta
        bounds, nb = geometry.residual_bounds(a,b,h,na)
        L, R = max(Ls[step],Ls[step+1]), bounds['R']
        Q = exp_upper(L*h)
        # Directed rounding controls expression size and preserves upper bound.
        E = upper_round(Q*(E+h*R))
        rows.append({'step':step+1,'t0':frac_string(ta),'t1':frac_string(tb),
                     'L_upper':rational_view(L),'R_upper':rational_view(R),
                     'R_interior_upper':rational_view(bounds['R_interior']),
                     'R_exterior_upper':rational_view(bounds['R_exterior']),
                     'exp_Lh_upper':rational_view(Q),
                     'E_end_upper':rational_view(E),
                     'bernstein_l2_squared':[frac_string(x) for x in bounds['bernstein_l2_squared']],
                     'nonzero_exterior_modes':bounds['nonzero_exterior_modes']})
        na = nb
    recon_path = None
    if output:
        output.parent.mkdir(parents=True,exist_ok=True)
        recon_path = output.with_suffix('.reconstruction.json')
        recon_path.write_bytes(canonical+b'\n')
    report = {
        'status':'RIGOROUS_RATIONAL_RESIDUAL_BOUND_CONDITIONAL_ON_RELATIVE_ENERGY_THEOREM',
        'quantity':'normalized L2 distance from rational piecewise-linear reconstruction to any Leray-Hopf solution',
        'domain':'(R/(2*pi*Z))^3','viscosity':'1/1',
        'exact_initial_condition':'W=(sin z,sin x,sin y)' if kind=='W' else '(sin y,0,0)',
        'exact_initial_shear_perturbation':frac_string(perturbation),
        'final_time':frac_string(times[-1]),'steps':len(rows),
        'interior_modes':len(modes),'full_residual_modes':len(geometry.outputs),
        'exterior_residual_modes':len(geometry.outputs)-len(modes),
        'endpoint_quantization_bits':bits,'endpoint_uniform_denominator':str(D),
        'upper_rounding_bits':PRECISION,
        'initial_error_upper':rational_view(sqrt_upper(E0sq)),
        'final_error_upper':rational_view(E),
        'source_npz_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'reconstruction_canonical_sha256':endpoint_sha,
        'reconstruction_file':recon_path.name if recon_path else None,
        'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'method':{'reference':'exactly divergence-free conjugate-symmetric finite Fourier endpoints; linear time interpolation',
                  'residual':'exact full Fourier convolution and exact Leray projection; quadratic Bernstein coefficients bound the whole step',
                  'strain':'sum over all modes of sqrt(|k|^2*|vhat_k|^2/2), maximum of endpoint bounds',
                  'square_root':'integer isqrt with upward dyadic rounding',
                  'exponential':'degree >=18 rational Taylor polynomial plus geometric positive-tail bound and upward rounding',
                  'propagation':'E_next=round_up(exp_upper(L*h)*(E+h*R))'},
        'captured_errors':['finite Fourier truncation via every exterior convolution mode',
                           'time reconstruction error via the entire-step differential residual',
                           'difference from prescribed exact initial data',
                           'endpoint quantization, projection, and numerical-generation errors through reconstructed residual'],
        'not_certified':['floating RK4 internal stages or an arbitrary interpolant',
                         'the paper global-time Picard theorem, novelty, or industrial benefit',
                         'an independently machine-formalized relative-energy theorem',
                         'general 3D Navier-Stokes regularity or weak-solution uniqueness'],
        'tamper_amplitude':frac_string(tamper_amplitude),
        'step_bounds':rows,'seconds':perf_counter()-started}
    if output:
        output.write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trajectory',type=Path)
    parser.add_argument('--output',type=Path,default=Path('certificate.json'))
    parser.add_argument('--bits',type=int,default=40)
    parser.add_argument('--initial',choices=['W','shear'],default='W')
    parser.add_argument('--perturbation',type=F,default=F(0))
    parser.add_argument('--tamper-amplitude',type=F,default=F(0))
    args=parser.parse_args()
    if not 16 <= args.bits <= 100:
        parser.error('--bits must be between 16 and 100')
    r=certify(args.trajectory,args.output,args.bits,args.initial,args.perturbation,args.tamper_amplitude)
    print(json.dumps({k:r[k] for k in ['status','steps','interior_modes','full_residual_modes','initial_error_upper','final_error_upper','seconds']},indent=2))

if __name__=='__main__':
    main()
