"""Equal certified tolerance follow-up; fixed target 1/200, five cold trials.

Candidates are restricted to the already measured 12-case grid. The quickest
eligible case per method is selected using generation+checker medians. This
compares the delivered Python implementations in one shared host, not general
CFD packages. End-to-end includes setup, generation, NPZ save, and certificate
read/reconstruction/output writes; it excludes interpreter/import startup.
"""
import json, hashlib
from pathlib import Path
from fractions import Fraction as F
from time import perf_counter
from types import SimpleNamespace
import numpy as np
from benchmark import HERE, OUT, summary
from solver import DirectGalerkin, save_trajectory
from certify import certify
from w2_reference import spherical_modes, build_reference_basis, evaluate_reference

TARGET=F(1,200)
REPEATS=5

def main():
    data=json.loads((HERE/'benchmark-results.json').read_text())
    selected=[]
    for method in ['w2','rk4']:
        eligible=[c for c in data['cases'] if c['method']==method and F(c['finalBoundFraction'])<=TARGET]
        assert eligible,method
        chosen=min(eligible,key=lambda c:c['generation']['medianSeconds']+c['certificate']['medianSeconds'])
        selected.append(chosen)
    observations={c['id']:[] for c in selected}
    outputs={}
    for trial in range(REPEATS):
        for c in selected[::1 if trial%2==0 else -1]:
            d=c['stepDenominator'];times=np.arange(d//4+1,dtype=float)/d
            start=perf_counter()
            if c['method']=='rk4':
                system=DirectGalerkin(3)
                _,frames=system.integrate(.25,1/d)
            else:
                modes=spherical_modes(3)
                basis=build_reference_basis(modes)
                frames=evaluate_reference(times,2,basis)
                system=SimpleNamespace(cutoff=3,modes=modes)
            path=OUT/f'target_trajectory_{c["id"]}.npz'
            save_trajectory(path,system,times,frames)
            report=certify(path,OUT/f'target_certificate_{c["id"]}.json')
            elapsed=perf_counter()-start
            assert F(report['final_error_upper']['fraction'])==F(c['finalBoundFraction'])
            observations[c['id']].append(elapsed)
            outputs[c['id']]=report['final_error_upper']
        print(f'Equal-target trial {trial+1}/{REPEATS} complete',flush=True)
    result={'targetFraction':str(TARGET),'target':float(TARGET),'trials':REPEATS,
      'selection':'Among the already measured 12 cases, choose the lowest generation+certificate median per method with exact final bound <=1/200. This finite-grid choice is not global optimization.',
      'measurement':'Cold method setup + endpoint generation + compressed input write + full certificate read/reconstruction/calculation/report writes. Imports/interpreter startup excluded. Deterministic alternating order.',
      'cases':[{'id':c['id'],'method':c['method'],'stepDenominator':c['stepDenominator'],
         'finalBound':c['finalBound'],'finalBoundFraction':c['finalBoundFraction'],
         'finalBoundOutward':c['finalBoundOutward'],'endToEnd':summary(observations[c['id']])} for c in selected],
      'sourceHashes':{'target_benchmark.py':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
      'scope':'Machine-specific prototype timings. Both meet the same certified tolerance; no true-error ranking, novelty, full-theorem validation, or industrial superiority claim.'}
    (HERE/'target-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
