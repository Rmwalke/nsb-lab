"""Direct, unaliased Fourier-Galerkin solver on the 2*pi periodic torus.

This is a numerical trajectory generator, NOT an interval arithmetic proof.
Convention: u(x,t) = sum_k uhat[k,t] exp(i*k.x), viscosity = 1.
The zero Fourier coefficient is zero.  Positive and negative modes are stored.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from time import perf_counter

import numpy as np


def spherical_modes(cutoff: int) -> np.ndarray:
    """All nonzero integer wavevectors in a Euclidean radius-N ball."""
    return np.array(
        [(a, b, c) for a in range(-cutoff, cutoff + 1)
         for b in range(-cutoff, cutoff + 1)
         for c in range(-cutoff, cutoff + 1)
         if 0 < a*a + b*b + c*c <= cutoff*cutoff], dtype=np.int64)


class DirectGalerkin:
    """RK4-ready finite spectral system with no FFT/circular convolution."""

    def __init__(self, cutoff: int):
        if int(cutoff) != cutoff or cutoff < 1:
            raise ValueError("cutoff must be a positive integer")
        self.cutoff = int(cutoff)
        self.modes = spherical_modes(cutoff)
        self.k2 = np.sum(self.modes**2, axis=1)
        self.index = {tuple(k): i for i, k in enumerate(self.modes)}
        self.negative = np.array([self.index[tuple(-k)] for k in self.modes])
        # Retain all ordered input pairs. Their destinations cover interior AND
        # exterior residual modes; no modulus, mode wrapping or aliasing occurs.
        m = len(self.modes)
        self.p = np.repeat(np.arange(m), m)
        self.q = np.tile(np.arange(m), m)
        destinations = self.modes[self.p] + self.modes[self.q]
        self.output_modes, all_output_index = np.unique(
            np.concatenate([destinations, self.modes]), axis=0, return_inverse=True)
        self.output_index = all_output_index[:m*m]
        self.output_k2 = np.sum(self.output_modes**2, axis=1)
        out_index = {tuple(k): i for i, k in enumerate(self.output_modes)}
        self.interior_output = np.array([out_index[tuple(k)] for k in self.modes])

    @staticmethod
    def leray(coefficients: np.ndarray, modes: np.ndarray) -> np.ndarray:
        """Orthogonal Leray projection; zero mode is set to zero."""
        result = coefficients.copy()
        norm2 = np.sum(modes*modes, axis=1)
        nonzero = norm2 > 0
        dots = np.sum(result[nonzero] * modes[nonzero], axis=1)
        result[nonzero] -= modes[nonzero] * (dots/norm2[nonzero])[:, None]
        result[~nonzero] = 0
        return result

    def nonlinear_all(self, uhat: np.ndarray) -> np.ndarray:
        """P((u.grad)u) on ALL possible output modes, including |k| > N."""
        dot = np.sum(self.modes[self.q] * uhat[self.p], axis=1)
        terms = 1j * dot[:, None] * uhat[self.q]
        conv = np.zeros((len(self.output_modes), 3), dtype=np.complex128)
        # bincount on real and imaginary parts is fast and preserves genuine
        # finite convolution. It is floating point, not outward rounded.
        for j in range(3):
            conv[:, j] = (np.bincount(self.output_index,
                                     weights=terms[:, j].real,
                                     minlength=len(conv))
                           + 1j*np.bincount(self.output_index,
                                           weights=terms[:, j].imag,
                                           minlength=len(conv)))
        return self.leray(conv, self.output_modes)

    def rhs(self, uhat: np.ndarray) -> np.ndarray:
        return (-self.k2[:, None]*uhat
                - self.nonlinear_all(uhat)[self.interior_output])

    def initial(self, kind: str = "W", perturbation: float = 0.0) -> np.ndarray:
        """W=(sin z,sin x,sin y), or exact decaying shear (sin y,0,0).

        Optional perturbation is h=perturbation*(sin y,0,0), for which A_-1(h)
        equals abs(perturbation). This labels data; no PDE validity is asserted.
        """
        uhat = np.zeros((len(self.modes), 3), dtype=np.complex128)
        components = [((0, 1, 0), 0, 1.0)] if kind == "shear" else [
            ((0, 0, 1), 0, 1.0), ((1, 0, 0), 1, 1.0),
            ((0, 1, 0), 2, 1.0)]
        if kind == "W" and perturbation:
            components.append(((0, 1, 0), 0, perturbation))
        for k, j, amplitude in components:
            uhat[self.index[k], j] += -0.5j*amplitude
            uhat[self.index[tuple(-np.array(k))], j] += 0.5j*amplitude
        return uhat

    def diagnostic(self, uhat: np.ndarray) -> dict:
        norms = np.linalg.norm(uhat, axis=1)
        kdotu = np.sum(uhat*self.modes, axis=1)
        rhs = self.rhs(uhat)
        eprime = float(np.real(np.vdot(uhat, rhs)))
        dissipation = float(np.sum(self.k2*norms**2))
        return {
            "A0": float(np.sum(norms)),
            "A1": float(np.sum(np.sqrt(self.k2)*norms)),
            "A_minus_1": float(np.sum(norms/np.sqrt(self.k2))),
            "energy_half_mean_square": float(np.sum(norms**2)/2),
            "max_divergence_coefficient": float(np.max(np.abs(kdotu))),
            "max_reality_defect": float(np.max(np.abs(
                uhat[self.negative]-np.conjugate(uhat)))),
            "energy_rhs": eprime,
            "viscous_dissipation": dissipation,
            "energy_identity_abs_residual": abs(eprime+dissipation),
        }

    def integrate(self, final_time: float, dt: float, kind: str = "W",
                  perturbation: float = 0.0) -> tuple[np.ndarray, np.ndarray]:
        steps = int(round(final_time/dt))
        if steps < 1 or not np.isclose(steps*dt, final_time, rtol=0, atol=1e-14):
            raise ValueError("final_time must be an integer multiple of dt")
        times = np.arange(steps+1)*dt
        trajectory = np.empty((steps+1, len(self.modes), 3), dtype=np.complex128)
        trajectory[0] = self.initial(kind, perturbation)
        for j in range(steps):
            u = trajectory[j]
            k1 = self.rhs(u)
            k2 = self.rhs(u + dt*k1/2)
            k3 = self.rhs(u + dt*k2/2)
            k4 = self.rhs(u + dt*k3)
            trajectory[j+1] = u+dt*(k1+2*k2+2*k3+k4)/6
        return times, trajectory


def save_trajectory(path: Path, system: DirectGalerkin, times: np.ndarray,
                    trajectory: np.ndarray) -> None:
    np.savez_compressed(path, times=times, modes=system.modes,
                        uhat_real=trajectory.real, uhat_imag=trajectory.imag,
                        cutoff=system.cutoff, viscosity=1.0,
                        convention="u(x)=sum_k uhat_k exp(i k.x)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cutoff", type=int, default=3)
    parser.add_argument("--dt", type=float, default=1/256)
    parser.add_argument("--time", type=float, default=0.25)
    parser.add_argument("--initial", choices=["W", "shear"], default="W")
    parser.add_argument("--perturbation", type=float, default=0.0)
    parser.add_argument("--output", type=Path, default=Path("trajectory.npz"))
    args = parser.parse_args()
    started = perf_counter()
    system = DirectGalerkin(args.cutoff)
    times, trajectory = system.integrate(args.time, args.dt, args.initial,
                                        args.perturbation)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    save_trajectory(args.output, system, times, trajectory)
    report = {"status": "NUMERICAL_TRAJECTORY_NOT_CERTIFICATE",
              "cutoff": args.cutoff, "modes": len(system.modes),
              "all_nonlinear_output_modes": len(system.output_modes),
              "time": args.time, "dt": args.dt, "steps": len(times)-1,
              "initial": args.initial, "perturbation": args.perturbation,
              "initial_diagnostics": system.diagnostic(trajectory[0]),
              "final_diagnostics": system.diagnostic(trajectory[-1]),
              "seconds": perf_counter()-started}
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
