"""Focused correctness checks for the explicit paper reference evaluator.

These checks validate implementation identities and numerical evaluation;
they do not constitute an independent proof of the manuscript's theorem.
"""
from decimal import Decimal, localcontext
import json
from pathlib import Path

import numpy as np

from w2_reference import (build_reference_basis, evaluate_reference,
                          exact_amplitude_formula, heat_profiles,
                          spherical_modes)


def decimal_profiles(t):
    with localcontext() as ctx:
        ctx.prec = 90
        t = Decimal(str(t))
        e = lambda n: (-n*t).exp()
        return ((e(1)-(1+2*t)*e(3))/4,
                (e(5)+(2*t-1)*e(3))/4,
                ((2*t*t-2*t+1)*e(4)-e(6))/4)


def main():
    modes = spherical_modes(3)
    basis = build_reference_basis(modes)
    times = np.array([0., 1e-12, 1e-8, .001, .01, .0625, .125,
                      .25, .25001, .5, 1., 4., 20.])
    frames = evaluate_reference(times, 2, basis)
    assert np.array_equal(evaluate_reference(np.array([0.]), 0, basis)[0], basis["W"])
    assert np.array_equal(evaluate_reference(np.array([0.]), 1, basis)[0], basis["W"])
    assert np.array_equal(frames[0], basis["W"])
    bymode = {tuple(k): i for i, k in enumerate(modes)}
    negative = np.array([bymode[tuple(-k)] for k in modes])
    divergence = float(np.max(np.abs(np.sum(frames*modes[None, :, :], axis=2))))
    reality = float(np.max(np.abs(frames[:, negative]-np.conj(frames))))
    assert divergence < 1e-17
    assert reality == 0
    active = np.any(np.abs(frames)>0, axis=(0, 2))
    assert int(np.sum(active)) == 54
    assert int(np.max(np.sum(modes[active]**2, axis=1))) == 6
    measured = np.linalg.norm(frames, axis=2).sum(axis=1)
    amplitude = exact_amplitude_formula(times)
    a0_error = float(np.max(np.abs(measured-amplitude)))
    assert np.allclose(measured, amplitude, rtol=2e-15, atol=2e-15)

    profiles = heat_profiles(times)
    max_relative = 0.
    for i, t in enumerate(times):
        oracle = decimal_profiles(t)
        for j in range(3):
            expected, found = float(oracle[j]), float(profiles[j][i])
            assert found >= 0
            if expected:
                error = abs(found-expected)/abs(expected)
                max_relative = max(max_relative, error)
                assert error < 3e-14, (t, j, found, expected, error)
            else:
                assert found == 0

    # Recover explicitly prescribed trig fields at points independently of
    # sparse-field construction and mode summation conventions.
    max_trig_error = 0.
    for point in [(0.13, -0.7, 1.2), (.5, .6, .7), (2., 3., -4.)]:
        x, y, z = point
        exact = {
            "W": np.array([np.sin(z), np.sin(x), np.sin(y)]),
            "F": np.array([np.sin(y)*np.cos(z), np.sin(z)*np.cos(x),
                           np.sin(x)*np.cos(y)]),
            "C": .5*np.array([np.sin(z)*np.cos(2*y), np.sin(x)*np.cos(2*z),
                              np.sin(y)*np.cos(2*x)])}
        phase = np.exp(1j*(modes@np.array(point)))
        for name, expected in exact.items():
            found = np.sum(basis[name]*phase[:, None], axis=0)
            error = float(np.max(np.abs(found-expected)))
            max_trig_error = max(max_trig_error, error)
            assert error < 5e-16

    errors = 0
    for times_bad in [[-1.], [float("nan")], [float("inf")]]:
        try:
            evaluate_reference(np.array(times_bad), 2, basis)
        except ValueError:
            errors += 1
    try:
        build_reference_basis(modes[np.sum(modes*modes, axis=1)<=4])
    except ValueError:
        errors += 1
    try:
        build_reference_basis(np.concatenate([modes, modes[:1]]))
    except ValueError:
        errors += 1
    assert errors == 5

    report = {
        "status": "PASS_IMPLEMENTATION_CHECKS_NOT_PROOF_OF_PAPER",
        "exact_spatial_checks": ["F=B(W,W)", "B(W,F)+B(F,W)=-W/2+C",
                                  "all_bases_divergence_free", "all_bases_conjugate_real"],
        "stored_modes": len(modes), "active_w2_modes": int(active.sum()),
        "max_active_k_squared": 6,
        "max_divergence_coefficient": divergence,
        "max_reality_defect": reality,
        "max_A0_formula_absolute_error": a0_error,
        "max_heat_profile_relative_error_vs_90digit_decimal": max_relative,
        "max_trig_evaluation_error": max_trig_error,
        "invalid_input_rejections": errors,
        "test_times": times.tolist()}
    path = Path(__file__).with_name("w2_implementation_validation.json")
    path.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
