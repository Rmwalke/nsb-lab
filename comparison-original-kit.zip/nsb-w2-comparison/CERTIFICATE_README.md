# Exact finite-time residual certificate

`certify.py` bounds the normalized spatial L2 distance between an exactly
specified reference trajectory and **any Leray–Hopf solution** of the unforced
incompressible Navier–Stokes equations on the 2π-periodic torus, viscosity 1,
with initial velocity W = (sin z, sin x, sin y).

This is a new finite-time prototype based on the standard relative-energy
argument. It is **not a certification of the paper's global-time Picard theorem**,
its X norm, its novelty, or an industrial advantage. The analytic theorem and
implementation are explained and checked, but are not formalized in Lean.

## Reproduce

Python 3 with NumPy is sufficient. Numerical trajectory generation is floating
point; the certificate computation is exact integer/rational arithmetic.

```sh
python solver.py --cutoff 3 --dt 0.0078125 --time 0.25 --output trajectory.npz
python certify.py trajectory.npz --output certificate.json
python validate_certificate.py
```

The final command uses the bundled four numerical input files. `certify.py`
reads the actual NPZ contents; it does not trust numerical diagnostics from the
solver or a saved output report.

## Exact object being certified

The floating endpoint coefficients are converted from their exact IEEE ratios,
quantized to a 2^-40 lattice, projected by the exact rational Fourier Leray
projection, and conjugated in ±k pairs. The resulting real, divergence-free
Fourier vector field is linearly interpolated in time. The initial coefficients
of W are represented exactly, so the initial error for the included cases is 0.

The certificate is about this **rational, projected, piecewise-linear field**.
It does not assert an error bound for arbitrary interpolation or the internal
RK4 stages. A graphical rendering necessarily converts coefficients to display
numbers; the downloadable rational reconstruction defines the actual reference.

Every `.reconstruction.json` stores:

- `modes`: integer vectors in the reference Fourier support;
- `times`: exact fraction strings;
- `denominator`: the common endpoint denominator D;
- `endpoints[time][mode]`: six integer numerators, in the order real x,y,z,
  imaginary x,y,z, all divided by D.

The canonical hash excludes the final newline in this reconstruction file.
The certificate also records the input NPZ and checker SHA-256 hashes.

## Why the bound covers time and spatial errors

Write the reconstructed field v and its **full PDE residual** as

    r = v_t - Δv + P((v · ∇)v).

The convection convolution includes **all** ordered pairs of reference Fourier
modes, including every mode outside the Galerkin cutoff. There is no FFT wrapping
or aliasing. The zero-mode convolution is explicitly required to vanish exactly.
For each time step, r is quadratic in the normalized time coordinate s. Its
Bernstein coefficients are

    B0 = (b-a)/h + |k|² a + Q(a,a),
    B1 = (b-a)/h + |k|²(a+b)/2 + [Q(a,b)+Q(b,a)]/2,
    B2 = (b-a)/h + |k|² b + Q(b,b).

The vector r(s) is a convex combination of these three vectors. Parseval's
identity therefore gives the rigorous whole-step bound

    R >= max_j sqrt(sum_k |Bj[k]|²).

This is a bound over the **entire step**, not sampled residual evaluation. The
sum includes all residual modes, including zero and exterior modes. Splitting
interior and exterior norms is a diagnostic only; propagation uses the full
residual norm.

For e=u-v and E=||e||_2, the relative-energy inequality gives

    (1/2) d(E²)/dt <= L E² + R E,

where L bounds the operator norm of the symmetric gradient of v at every spatial
point and time in that step. Exact divergence freedom implies

    ||sym(i vhat_k tensor k)||_F² = |k|² |vhat_k|² / 2.

Thus a sufficient L is the maximum at the two endpoints of the sum over all ±k
of sqrt(|k|² |vhat_k|² / 2). Convexity covers linear interpolation in time. The
regularized scalar comparison implies the conservative recurrence

    E_next <= exp(L h) (E + h R).

Square roots use integer `isqrt` and directed upward rounding. Exponentials use
an exact rational Taylor polynomial and a geometric upper bound on the complete
positive tail. All updates round upward to a 2^-60 lattice; there are no
floating-point comparisons in the bound calculation. Decimal report fields are
only display approximations of the accompanying exact fractions.

Because the residual tests the reconstructed field against the full PDE,
numerical generation, endpoint projection/quantization, temporal reconstruction,
and neglected spatial Fourier modes are covered together. This does not
identify a separate additive contribution for every source of error.

## Executed results for W, 0 <= t <= 1/4

All rows start with exact error 0. The reference has 32 modes at N=2 and 122 at
N=3. The full residual support contains 185 and 829 modes, respectively.

| Cutoff | Step h | Steps | Final normalized L2 error upper bound (approx.) |
|---|---|---:|---:|
| N=2 | 1/64 | 16 | 0.01360794862824609 |
| N=2 | 1/128 | 32 | 0.011498015769951131 |
| N=3 | 1/64 | 16 | 0.007142942122230646 |
| N=3 | 1/128 | 32 | 0.0035463291376414876 |

The last bound is exactly `2044319562600363/576460752303423488`.
The quantity is sqrt((2π)^-3 integral |u-v|² dx), not a pointwise velocity error,
not a relative percentage, and not the paper's global X-norm error.

## Meaningful checks executed

- An independently specified linear shear v=(1-t)sin(y)e_x has exact residual
  -t sin(y)e_x. The three Bernstein squared norms were exactly 0, 1/128, 1/32.
- A separate Fraction-based convolution implementation checked all 185 output
  modes and all three Bernstein norms on the first N=2 step, agreeing exactly.
- Tests confirm that nonzero exterior residual modes are actually retained.
- A controlled 1/8 sin(z)e_x excursion at the N=3,h=1/128 midpoint increases the
  bound from approximately 0.00354633 to 0.23788314 (about 67 times worse).
  A worse bound does not prove that the true solution error is equally large.
- Boundary checks cover zero square root/exponential and upward square roots.

The code and mathematical argument should still be independently reviewed.
No claim is made about general 3D regularity, uniqueness, unbounded time,
engineering geometry, physical dimensions, patentability, or superiority to
other validated numerical methods.
