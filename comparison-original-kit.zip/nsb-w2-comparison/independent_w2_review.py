"""Independent complex-Fourier/Duhamel checks of manuscript equation main:w2.

No solver or certificate implementation is imported for the reference checks.
The optional implementation file is loaded only after computing independent
reference answers. Floating quadrature is a consistency test, not a proof.
"""
from pathlib import Path
import argparse
import importlib.util
import hashlib
import json
import math
import numpy as np


def add(*terms):
    out = {}
    for scalar, field in terms:
        for k, v in field.items():
            out[k] = out.get(k, np.zeros(3, dtype=complex)) + scalar * v
    return {k: v for k, v in out.items() if np.max(np.abs(v)) > 1e-28}


def trig(sine_axis, cosine_axis=None, cosine_frequency=1, component=0, scale=1):
    """Literal Fourier expansion of scale*sin(x_a)*cos(m*x_b)."""
    out = {}
    for sign in (-1, 1):
        for cos_sign in ((-1, 1) if cosine_axis is not None else (0,)):
            k = [0, 0, 0]
            k[sine_axis] = sign
            if cosine_axis is not None:
                k[cosine_axis] = cos_sign * cosine_frequency
            v = np.zeros(3, dtype=complex)
            v[component] = -0.5j * sign * scale * (0.5 if cosine_axis is not None else 1)
            out[tuple(k)] = v
    return out


W = add((1, trig(2, component=0)), (1, trig(0, component=1)), (1, trig(1, component=2)))
F = add((1, trig(1, 2, component=0)), (1, trig(2, 0, component=1)), (1, trig(0, 1, component=2)))
C = add((1, trig(2, 1, 2, component=0, scale=.5)), (1, trig(0, 2, 2, component=1, scale=.5)), (1, trig(1, 0, 2, component=2, scale=.5)))


def convection(f, g):
    """Full B(f,g)_k=i P_k sum_{p+q=k} (f_p dot q) g_q; no cutoff."""
    raw = {}
    for p, fp in f.items():
        for q, gq in g.items():
            k = tuple(p[j] + q[j] for j in range(3))
            raw[k] = raw.get(k, np.zeros(3, dtype=complex)) + 1j * np.dot(fp, q) * gq
    out = {}
    for k, v in raw.items():
        kk = sum(x*x for x in k)
        if kk:
            v = v - np.asarray(k) * (np.dot(k, v) / kk)
            if np.max(np.abs(v)) > 1e-28:
                out[k] = v
    return out


H = convection(F, F)


def sym_sum(f, g):
    return add((1, convection(f, g)), (1, convection(g, f)))


def max_diff(a, b):
    return max((float(np.max(np.abs(a.get(k, np.zeros(3)) - b.get(k, np.zeros(3))))) for k in a.keys() | b.keys()), default=0)


def l2(field):
    return math.sqrt(sum(float(np.vdot(v, v).real) for v in field.values()))


def profiles(t):
    x = math.exp(-t)
    y = t * math.exp(-2*t)
    p = (math.exp(-t) - (1+2*t)*math.exp(-3*t)) / 8
    q = (math.exp(-5*t) + (2*t-1)*math.exp(-3*t)) / 4
    r = ((2*t*t-2*t+1)*math.exp(-4*t) - math.exp(-6*t)) / 4
    return x, y, p, q, r


def explicit(t):
    x, y, p, q, r = profiles(t)
    return add((x-p, W), (-y, F), (q, C), (-r, H))


def duhamel(t, order):
    """Compute e^-t W-integral e^{(t-s)Delta}B(w1,w1)ds directly."""
    nodes, weights = np.polynomial.legendre.leggauss(order)
    integral = {}
    for node, weight in zip(nodes, weights):
        s = t*(node+1)/2
        w1 = add((math.exp(-s), W), (-s*math.exp(-2*s), F))
        b = convection(w1, w1)
        for k, v in b.items():
            scale = (t*weight/2)*math.exp(-sum(x*x for x in k)*(t-s))
            integral[k] = integral.get(k, np.zeros(3, dtype=complex)) + scale*v
    return add((math.exp(-t), W), (-1, integral))


def residual_direct(t):
    x, y, p, q, r = profiles(t)
    dp = (t*math.exp(-3*t) - 2*p)/2
    dq = t*math.exp(-3*t) - 5*q
    dr = t*t*math.exp(-4*t) - 6*r
    v = explicit(t)
    derivative = add((-x-dp, W), (-(1-2*t)*math.exp(-2*t), F), (dq, C), (-dr, H))
    av = {k: sum(x*x for x in k)*v_k for k, v_k in v.items()}
    return add((1, derivative), (1, av), (1, convection(v, v)))


def residual_formula(t):
    x, y, p, q, r = profiles(t)
    G = add((-.5, W), (1, C))
    return add((p*p-2*x*p, F), (y*p, G), ((x-p)*q, sym_sum(W, C)),
               (-(x-p)*r, sym_sum(W, H)), (-y*q, sym_sum(F, C)),
               (y*r, sym_sum(F, H)), (q*q, convection(C, C)),
               (-q*r, sym_sum(C, H)), (r*r, convection(H, H)))


def run():
    report = {
        "method": "Independent literal complex Fourier convolution and Gauss-Legendre evaluation of SW-Q(w1,w1); no solver/certificate implementation used for these references.",
        "scope": "Numerical consistency validation; not a rigorous interval enclosure or independent proof of the manuscript theorem.",
        "field_checks": {
            "B_WW_minus_literal_F_max": max_diff(convection(W, W), F),
            "B_WF_plus_B_FW_minus_literal_G_max": max_diff(sym_sum(W, F), add((-.5, W), (1, C))),
            "W_modes": len(W), "F_modes": len(F), "C_modes": len(C), "H_modes": len(H),
        },
        "times": []
    }
    for t in (0.0, .0625, .125, .25):
        v = explicit(t)
        q32 = duhamel(t, 32)
        q64 = duhamel(t, 64)
        direct = residual_direct(t)
        formula = residual_formula(t)
        report["times"].append({
            "time": t, "explicit_vs_duhamel64_max_coefficient": max_diff(v, q64),
            "quadrature32_vs64_max_coefficient": max_diff(q32, q64),
            "residual_formula_vs_direct_max_coefficient": max_diff(direct, formula),
            "w2_active_modes": len(v),
            "w2_max_mode_squared": max(sum(i*i for i in k) for k in v),
            "residual_active_modes_above_1e_minus14": int(sum(np.max(np.abs(a)) > 1e-14 for a in direct.values())),
            "residual_max_mode_squared_above_1e_minus14": max((sum(i*i for i in k) for k, a in direct.items() if np.max(np.abs(a)) > 1e-14), default=0),
            "max_divergence_coefficient": max(abs(np.dot(k, a)) for k, a in v.items()),
            "max_reality_defect": max(float(np.max(np.abs(a - np.conj(v[tuple(-i for i in k)])))) for k,a in v.items()),
            "normalized_l2": l2(v),
        })
    assert report["field_checks"]["B_WW_minus_literal_F_max"] < 1e-14
    assert report["field_checks"]["B_WF_plus_B_FW_minus_literal_G_max"] < 1e-14
    for row in report["times"]:
        assert row["explicit_vs_duhamel64_max_coefficient"] < 2e-15
        assert row["residual_formula_vs_direct_max_coefficient"] < 2e-15
        assert row["w2_max_mode_squared"] <= 6
    return report


def compare_implementation(path):
    path = Path(path).resolve()
    spec = importlib.util.spec_from_file_location("w2_implementation_under_test", path)
    impl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(impl)
    modes = impl.spherical_modes(3)
    basis = impl.build_reference_basis(modes)
    times = np.array([0.0, .0625, .125, .25])
    frames = impl.evaluate_reference(times, order=2, basis=basis)
    rows = []
    for t, coeff in zip(times, frames):
        got = {tuple(int(x) for x in k): a for k, a in zip(modes, coeff)}
        expected = duhamel(float(t), 64)
        active = {k for k, a in got.items() if np.max(np.abs(a)) > 1e-20}
        ref_active = {k for k, a in explicit(float(t)).items() if np.max(np.abs(a)) > 1e-20}
        error = max_diff(got, expected)
        row = {"time": float(t), "implementation_vs_independent_duhamel_max_coefficient": error,
               "active_support_matches": active == ref_active,
               "implementation_active_modes": len(active), "independent_active_modes": len(ref_active)}
        assert error < 2e-15
        assert row["active_support_matches"]
        rows.append(row)
    basis_checks = {}
    for name, ref in (("W", W), ("F", F), ("C", C), ("H", H)):
        got = {tuple(int(x) for x in k): a for k, a in zip(modes, basis[name])}
        basis_checks[name] = max_diff(got, ref)
        assert basis_checks[name] < 1e-15
    return {"implementation_file": str(path), "implementation_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "basis_max_coefficient_errors": basis_checks, "times": rows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(Path(__file__).with_name("independent_reference_validation.json")))
    parser.add_argument("--implementation")
    args = parser.parse_args()
    report = run()
    if args.implementation:
        report["implementation_comparison"] = compare_implementation(args.implementation)
    Path(args.out).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
