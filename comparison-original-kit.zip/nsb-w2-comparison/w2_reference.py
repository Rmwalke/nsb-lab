"""Evaluate the paper's explicit heat-seeded Picard references w0, w1, w2.

Spatial coefficients are built with exact Fraction arithmetic. Temporal
exponentials are ordinary floating point: output is numerical endpoint data,
not itself a rigorous certificate. The existing certify.py can independently
certify the resulting exact rational piecewise-linear reconstruction.

Fourier convention: u(x) = sum_k uhat[k] exp(i k.x). All bases here are odd,
so uhat = i*a with rational real a. No time stepping occurs in evaluation.
Source: manuscript section 2, equations main:fields, main:L, main:w2.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
from time import perf_counter

import numpy as np


def _add(field, mode, component, value):
    row = field.setdefault(tuple(mode), [Q(0), Q(0), Q(0)])
    row[component] += Q(value)


def _clean(field):
    return {k: tuple(v) for k, v in sorted(field.items()) if any(v)}


def _sine(field, axis, component, amplitude=Q(1)):
    for sign in [-1, 1]:
        k = [0, 0, 0]
        k[axis] = sign
        _add(field, k, component, -sign*amplitude/2)


def _sine_cosine(field, sin_axis, cos_axis, component,
                 cos_frequency=1, amplitude=Q(1)):
    for sine_sign in [-1, 1]:
        for cosine_sign in [-1, 1]:
            k = [0, 0, 0]
            k[sin_axis] = sine_sign
            k[cos_axis] = cosine_sign*cos_frequency
            _add(field, k, component, -sine_sign*amplitude/4)


def exact_bilinear(a, b):
    """Imaginary coefficients of B(i*a,i*b)=P((i*a).grad(i*b))."""
    result = {}
    for p, ap in a.items():
        for q, bq in b.items():
            dot = sum(ap[c]*q[c] for c in range(3))
            if dot:
                k = tuple(p[c]+q[c] for c in range(3))
                row = result.setdefault(k, [Q(0), Q(0), Q(0)])
                for c in range(3):
                    row[c] -= dot*bq[c]
    for k, row in result.items():
        norm = sum(c*c for c in k)
        if not norm:
            if any(row):
                raise ArithmeticError("unexpected nonzero mean convection")
            continue
        dot = sum(k[c]*row[c] for c in range(3))
        for c in range(3):
            row[c] -= k[c]*dot/norm
    return _clean(result)


def exact_linear_combination(*terms):
    result = {}
    for scalar, field in terms:
        for k, row in field.items():
            for c in range(3):
                _add(result, k, c, Q(scalar)*row[c])
    return _clean(result)


def exact_reference_fields():
    """Return sparse maps of exact imaginary coefficients W, F, C, H."""
    w, f, c = {}, {}, {}
    # W=(sin z,sin x,sin y).
    for axis, component in [(2, 0), (0, 1), (1, 2)]:
        _sine(w, axis, component)
    # F=(sin y cos z, sin z cos x, sin x cos y).
    for sin_axis, cos_axis, component in [(1, 2, 0), (2, 0, 1), (0, 1, 2)]:
        _sine_cosine(f, sin_axis, cos_axis, component)
    # C=1/2*(sin z cos 2y, sin x cos 2z, sin y cos 2x).
    for sin_axis, cos_axis, component in [(2, 1, 0), (0, 2, 1), (1, 0, 2)]:
        _sine_cosine(c, sin_axis, cos_axis, component,
                     cos_frequency=2, amplitude=Q(1, 2))
    w, f, c = _clean(w), _clean(f), _clean(c)
    if exact_bilinear(w, w) != f:
        raise ArithmeticError("F trig formula disagrees with B(W,W)")
    g = exact_linear_combination((1, exact_bilinear(w, f)),
                                 (1, exact_bilinear(f, w)))
    if g != exact_linear_combination((Q(-1, 2), w), (1, c)):
        raise ArithmeticError("G=-W/2+C identity failed")
    h = exact_bilinear(f, f)
    fields = {"W": w, "F": f, "C": c, "H": h}
    for name, field in fields.items():
        for k, row in field.items():
            if sum(k[j]*row[j] for j in range(3)):
                raise ArithmeticError(f"nonzero exact divergence in {name}")
            if field.get(tuple(-v for v in k)) != tuple(-v for v in row):
                raise ArithmeticError(f"reality/conjugacy failure in {name}")
    return fields


def build_reference_basis(modes):
    """Dense complex coefficient arrays, plus exact bases and mode metadata.

    modes must include the full support of all four bases (N=3 suffices).
    Return keys: modes,W,F,C,H,exact_imaginary,support_mode_count,max_k_squared.
    """
    values = np.asarray(modes)
    if values.ndim != 2 or values.shape[1] != 3:
        raise ValueError("modes must have shape (number_of_modes,3)")
    if not np.all(np.isfinite(values)) or not np.all(values == np.floor(values)):
        raise ValueError("modes must be finite integer triples")
    values = values.astype(np.int64)
    index = {tuple(int(v) for v in k): i for i, k in enumerate(values)}
    if len(index) != len(values):
        raise ValueError("duplicate Fourier mode")
    fields = exact_reference_fields()
    result = {"modes": values, "exact_imaginary": fields}
    support = set().union(*(set(f) for f in fields.values()))
    missing = support-set(index)
    if missing:
        raise ValueError(f"mode set omits reference support: {sorted(missing)}")
    for name, field in fields.items():
        coeff = np.zeros((len(values), 3), dtype=np.complex128)
        for k, row in field.items():
            coeff[index[k]] = [1j*float(a) for a in row]
        result[name] = coeff
    result["support_mode_count"] = len(support)
    result["max_k_squared"] = max(sum(v*v for v in k) for k in support)
    return result


def heat_profiles(times):
    """Stable float L1,L5,L6, using Taylor remainders for small t.

    Near zero L1 and L5 start at t^2/2, L6 at t^3/3. Direct subtraction
    of exponentials loses these terms. A convergent 22-term series avoids
    that cancellation for 2t<=0.5; larger t use decaying exponentials only.
    """
    t = np.asarray(times, dtype=float)
    if np.any(~np.isfinite(t)) or np.any(t < 0):
        raise ValueError("times must be finite and nonnegative")
    flat = t.reshape(-1)
    l1, l5, l6 = (np.zeros_like(flat) for _ in range(3))
    small = flat <= 0.25
    ts = flat[small]
    x = 2*ts
    pos = x*x/2
    neg = pos.copy()
    tail2pos, tail2neg = pos.copy(), neg.copy()
    tail3neg = np.zeros_like(x)
    for n in range(3, 23):
        pos *= x/n
        neg *= -x/n
        tail2pos += pos
        tail2neg += neg
        tail3neg += neg
    l1[small] = np.exp(-3*ts)*tail2pos/4
    l5[small] = np.exp(-3*ts)*tail2neg/4
    l6[small] = -np.exp(-4*ts)*tail3neg/4
    tl = flat[~small]
    # These forms do not form an overflowing positive exponential.
    l1[~small] = (np.exp(-tl)-(1+2*tl)*np.exp(-3*tl))/4
    l5[~small] = np.exp(-3*tl)*(np.expm1(-2*tl)+2*tl)/4
    l6[~small] = np.exp(-4*tl)*(2*tl*tl-2*tl-np.expm1(-2*tl))/4
    return tuple(v.reshape(t.shape) for v in (l1, l5, l6))


def evaluate_reference(times, order=2, basis=None):
    """Return float complex frames of shape (len(times),len(modes),3).

    order=0: e^-t W; order=1: e^-t W-t e^-2t F;
    order=2: (e^-t-L1/2)W-t e^-2t F+L5 C-L6 H.
    """
    if basis is None:
        raise ValueError("provide build_reference_basis(modes) as basis")
    if order not in (0, 1, 2):
        raise ValueError("order must be 0, 1, or 2")
    t = np.asarray(times, dtype=float)
    if t.ndim != 1 or np.any(~np.isfinite(t)) or np.any(t < 0):
        raise ValueError("times must be a one-dimensional nonnegative finite array")
    x = np.exp(-t)
    if order == 0:
        return x[:, None, None]*basis["W"]
    y = t*np.exp(-2*t)
    if order == 1:
        return x[:, None, None]*basis["W"]-y[:, None, None]*basis["F"]
    l1, l5, l6 = heat_profiles(t)
    return ((x-l1/2)[:, None, None]*basis["W"]
            -y[:, None, None]*basis["F"]
            +l5[:, None, None]*basis["C"]-l6[:, None, None]*basis["H"])


def exact_amplitude_formula(times):
    """Paper's A0(w2) formula, evaluated in ordinary floating point."""
    t = np.asarray(times, dtype=float)
    _, _, l6 = heat_profiles(t)
    return (21/8*np.exp(-t)+3*t*np.exp(-2*t)
            +1.5*t*np.exp(-3*t)+3/8*np.exp(-5*t)+np.sqrt(3)*l6)


def spherical_modes(cutoff=3):
    """Same lexicographic Euclidean-ball mode layout as solver.py."""
    if int(cutoff) != cutoff or cutoff < 3:
        raise ValueError("cutoff must be an integer at least 3 for full w2 support")
    return np.array([(a, b, c) for a in range(-cutoff, cutoff+1)
                     for b in range(-cutoff, cutoff+1)
                     for c in range(-cutoff, cutoff+1)
                     if 0 < a*a+b*b+c*c <= cutoff*cutoff], dtype=np.int64)


def save_reference(path, times, frames, basis, cutoff=3, order=2):
    """Write the existing certify.py's trajectory input format."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, times=np.asarray(times), modes=basis["modes"],
                        uhat_real=frames.real, uhat_imag=frames.imag,
                        cutoff=cutoff, viscosity=1.0,
                        convention="u(x)=sum_k uhat_k exp(i k.x)",
                        reference_order=order,
                        generator="paper_explicit_heat_seeded_Picard_reference")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cutoff", type=int, default=3)
    parser.add_argument("--dt", type=float, default=1/128)
    parser.add_argument("--time", type=float, default=0.25)
    parser.add_argument("--order", type=int, choices=(0, 1, 2), default=2)
    parser.add_argument("--output", type=Path, default=Path("trajectory_w2.npz"))
    args = parser.parse_args()
    if not np.isfinite(args.dt) or args.dt <= 0 or not np.isfinite(args.time) or args.time <= 0:
        parser.error("time and dt must be positive and finite")
    steps = int(round(args.time/args.dt))
    if steps < 1 or not np.isclose(steps*args.dt, args.time, rtol=0, atol=1e-14):
        parser.error("time must be an integer multiple of dt")
    started = perf_counter()
    modes = spherical_modes(args.cutoff)
    basis = build_reference_basis(modes)
    setup_seconds = perf_counter()-started
    times = np.arange(steps+1)*args.dt
    started = perf_counter()
    frames = evaluate_reference(times, args.order, basis)
    evaluation_seconds = perf_counter()-started
    save_reference(args.output, times, frames, basis, args.cutoff, args.order)
    report = {"status": "NUMERICAL_ENDPOINTS_NOT_CERTIFICATE",
              "method": f"explicit_w{args.order}", "cutoff": args.cutoff,
              "stored_modes": len(modes), "support_modes_w2": basis["support_mode_count"],
              "max_k_squared_w2": basis["max_k_squared"],
              "time": args.time, "dt": args.dt, "steps": steps,
              "basis_setup_seconds": setup_seconds,
              "evaluation_seconds": evaluation_seconds,
              "final_A0": float(np.linalg.norm(frames[-1], axis=1).sum()),
              "max_divergence_coefficient": float(np.max(np.abs(np.sum(frames*modes[None,:,:], axis=2))))}
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
