# Independent w2 implementation review

The manuscript's equations `main:fields`, `main:L`, `main:w2`, and `main:r2`
were read from `Code/manuscript/sections/02_main_proof.tex`. The checks below
are independent numerical consistency checks, not a proof of the full paper.

## Independent construction

`independent_w2_review.py` defines W, F, C by literal sine/cosine complex
Fourier expansions. Its full ordered-pair convection loop computes
`i P_k sum_(p+q=k) (f_p dot q) g_q` without a spatial cutoff. It constructs
H from B(F,F). It then evaluates

`exp(-t) W - integral_0^t exp((t-s) Delta) B(w1(s),w1(s)) ds`

using independent 32- and 64-point Gauss–Legendre quadrature. Neither solver,
certifier, nor w2 implementation is imported to produce the reference answers.
Only a subsequent optional comparison imports `w2_reference.py`.

At t = 0, 1/16, 1/8, 1/4, the implementation agrees with that independent
Duhamel evaluation to maximum coefficient difference 5.56e-17. The reference
32/64-point quadrature difference is at most 5.56e-17. These floating-point
agreements are not rigorous error enclosures.

For positive tested times, w2 has 54 active modes, all satisfying |k|² <= 6.
There is no loss of reference support in the implementation's N=3 mode set.
The independent main:r2 residual expansion agrees with direct differentiation
plus diffusion and full convection to 6.77e-17. The full analytic w2 residual
has 342 modes above 1e-14, through |k|² = 22. Residual modes outside w2's
support must remain in every certificate.

The numerical report records the exact implementation file hash tested.
Run from the project workspace:

```sh
python independent_w2_review.py --implementation w2_reference.py
```

## Interpretation of comparison certificates

The shared rational certifier proves a finite-time, normalized spatial L²
bound for its exact rational piecewise-linear reconstruction. For w2, this
is the reconstruction of sampled explicit-formula values. It is not a
certificate directly for the continuous analytic exponential formula.
Finer sampling can improve this reconstruction and its certificate while
the analytic w2 value at the final time does not change.

This comparison does not test the paper's global L²-in-time A0 convergence
theorem. The relative-energy certificate is a separate standard finite-time
estimate. A numerical difference from a finer RK trajectory is an empirical
comparison, not a bound against the exact Navier–Stokes solution.

## Timing and usefulness

- Use identical domain, viscosity, initial data, horizon, output times, and
  certificate precision. Preserve all w2 modes and all residual output modes.
- Report setup, trajectory generation, and certificate time separately.
  Setup includes exact reference-field construction on the w2 side and
  interaction topology on the RK side. If setup is excluded, say so for both.
- Medians with warm-up reduce timing noise. They describe these programs on
  this machine; they do not establish fastest possible implementations.
- A faster method with a larger error bound demonstrates a cost–accuracy
  tradeoff. A useful speed advantage at a requested accuracy needs both
  methods to meet that same certified-error target.
- N=3 storage of 122 modes for both is a transparent common baseline. w2 has
  only 54 active modes; sparse optimization is a possible future improvement,
  not a measured result of a padded-mode baseline.
- A favorable benchmark for this single initial field and short time does not
  establish general industrial performance, novelty, or theorem correctness.
