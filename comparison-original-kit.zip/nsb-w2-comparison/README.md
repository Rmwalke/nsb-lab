# Reproduce the W2 / RK4 comparison

Python 3 with NumPy is required. All work is local; no login/network service is
needed after downloading. The formulas, original manuscript attribution,
protocol and limits are in COMPARISON_METHOD.md and W2_REFERENCE_README.md.

Check the explicit formula implementation:
    python test_w2_reference.py
    python independent_w2_review.py --implementation w2_reference.py

Recheck one archived certificate without changing its input:
    python certify.py results/trajectory_w2_dt256.npz --output rechecked_w2.json

Recompute all 12 cases and recorded timings, then the equal-target comparison:
    python benchmark.py
    python target_benchmark.py

These two commands overwrite the included benchmark results with local results.
Timing numbers will change on your machine. NPZ byte hashes can change when
rewritten; each freshly computed certificate records its corresponding input.
All rigorous quantities are exact fraction strings. Decimal fields and graphs
are display approximations. Upper bounds on the page are rounded upward.

The PDF theorem was not re-proved by this benchmark. This is an executable
finite-time comparison of the explicit w2 reference and a Python RK4 solver,
using a common full-PDE residual error checker. See COMPARISON_METHOD.md.
Prepared with AI assistance for Rushikesh Murlidhar Walke.
