# Explicit paper reference evaluator

`w2_reference.py` evaluates the explicit `w0`, `w1`, and `w2` formulas in
the manuscript's section “Explicit references and the complete heat defect.”
It requires Python 3 and NumPy. It makes no network requests.

```sh
python test_w2_reference.py
python w2_reference.py --order 2 --cutoff 3 --dt 0.0078125 --time 0.25 --output trajectory_w2.npz
```

The resulting NPZ has the same `times`, `modes`, `uhat_real`, `uhat_imag`,
`cutoff`, and `viscosity` fields as the numerical solver's output. It can be
passed to the existing, unchanged `certify.py`:

```sh
python certify.py trajectory_w2.npz --output certificate_w2.json
```

The certificate concerns the **exact rational piecewise-linear reconstruction
of the generated endpoints**, with viscosity 1, the stated periodic domain,
and initial field `W=(sin z,sin x,sin y)`. It does not certify the internal
floating-point evaluation or the continuous exponential formula directly.

## Python API

```python
import numpy as np
from w2_reference import build_reference_basis, evaluate_reference, spherical_modes

modes = spherical_modes(3)
basis = build_reference_basis(modes)
times = np.arange(33)/128
frames = evaluate_reference(times, order=2, basis=basis)
# frames.shape == (33, 122, 3), complex Fourier coefficients
```

`build_reference_basis` performs exact rational spatial algebra for all four
bases `W,F,C,H`, checks `F=B(W,W)` and `B(W,F)+B(F,W)=-W/2+C`, and constructs
dense complex arrays. It should be timed separately from repeated evaluation.
`evaluate_reference` performs no time stepping and can reuse this basis for
all orders. Both it and the RK4 generator supply ordinary floating-point
endpoint data to the same certificate algorithm.

The Fourier convention is `u(x)=sum_k uhat[k] exp(i k.x)`. The nonzero support
of `w2` is 54 modes with `|k|^2 <= 6`, stored in the shared 122-mode radius-3
layout. All spatial coefficients are purely imaginary. Heat profiles use
small-time Taylor remainders to avoid subtractive cancellation.

`test_w2_reference.py` checks exact identities, initial data, full support,
conjugacy, divergence, the paper's `A0(w2)` formula, trig reconstruction,
and heat profiles against 90-digit Decimal evaluation. Its JSON receipt is
an implementation check, not independent validation of the paper's theorem.

Timing or certificate comparisons must state their time interval, step sizes,
mode layout, hardware/runtime, whether setup is included, and norm. A faster
formula evaluation alone does not establish a useful accuracy advantage.
