"""Predeclared W reference comparison, one norm/checker/hardware context.

Run from the downloadable kit: python benchmark.py
Raw per-trial timings and rational certificate fractions are retained.
No reported endpoint difference is treated as the true PDE error.
"""
from pathlib import Path
from time import perf_counter
import hashlib, json, platform, statistics, sys
import numpy as np

HERE=Path(__file__).resolve().parent
if not (HERE/'solver.py').exists():
    sys.path.insert(0,str(HERE.parent/'nsb_w2_comparison'))
    sys.path.insert(0,str(HERE.parents[1]/'sites/nsb-experiment-lab/research-solver'))
from solver import DirectGalerkin, save_trajectory
from certify import certify
from w2_reference import build_reference_basis, evaluate_reference

METHODS=('w0','w1','w2','rk4')
DENOMINATORS=(64,128,256)
GENERATION_TRIALS=9
CERTIFICATE_TRIALS=3
SETUP_TRIALS=7
OUT=HERE/'results'

def summary(samples):
    return {'medianSeconds':statistics.median(samples),'minSeconds':min(samples),
      'maxSeconds':max(samples),'samplesSeconds':samples}

def timed(fn,repeats):
    a=[]
    for _ in range(repeats):
        t=perf_counter();fn();a.append(perf_counter()-t)
    return summary(a)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def outward6(frac):
    from fractions import Fraction
    q=Fraction(frac)
    n=(q.numerator*10**6+q.denominator-1)//q.denominator
    return f'{n//10**6}.{n%10**6:06d}'

def main():
    OUT.mkdir(exist_ok=True)
    system=DirectGalerkin(3)
    basis=build_reference_basis(system.modes)
    setup={'paper_shared_basis':timed(lambda:build_reference_basis(system.modes),SETUP_TRIALS),
           'rk4_geometry':timed(lambda:DirectGalerkin(3),SETUP_TRIALS)}
    cases=[]
    for d in DENOMINATORS:
        times=np.arange(d//4+1,dtype=float)/d
        generators={m:(lambda order=int(m[-1]):evaluate_reference(times,order,basis))
          for m in METHODS if m!='rk4'}
        generators['rk4']=lambda:system.integrate(.25,1/d)[1]
        samples={m:[] for m in METHODS}
        # One warmup then rotate order deterministically to reduce order bias.
        for g in generators.values():g()
        for j in range(GENERATION_TRIALS):
            for m in METHODS[j%4:]+METHODS[:j%4]:
                t=perf_counter();generators[m]();samples[m].append(perf_counter()-t)
        for m in METHODS:
            ident=f'{m}_dt{d}'
            frames=generators[m]()
            assert np.array_equal(frames[0],system.initial())
            path=OUT/f'trajectory_{ident}.npz'
            save_trajectory(path,system,times,frames)
            cert_times=[];fraction=None
            for trial in range(CERTIFICATE_TRIALS):
                started=perf_counter()
                report=certify(path,OUT/f'certificate_{ident}.json')
                cert_times.append(perf_counter()-started)
                f=report['final_error_upper']['fraction']
                if fraction is not None:assert f==fraction
                fraction=f
            cases.append({'id':ident,'method':m,'label':{'w0':'Heat reference w₀','w1':'Paper formula w₁','w2':'Paper formula w₂','rk4':'Fourier RK4'}[m],
              'stepDenominator':d,'steps':len(times)-1,
              'finalBound':report['final_error_upper']['decimal_approx'],
              'finalBoundFraction':fraction,'finalBoundOutward':outward6(fraction),
              'generation':summary(samples[m]),'certificate':summary(cert_times),
              'setup':setup['rk4_geometry' if m=='rk4' else 'paper_shared_basis'],
              'retainedModes':len(system.modes),
              'activeEndpointModes':int(np.count_nonzero(np.linalg.norm(frames[-1],axis=1))),
              'fullResidualModes':report['full_residual_modes'],
              'source_npz_sha256':report['source_npz_sha256'],
              'checker_sha256':report['checker_sha256'],
              'reconstruction_canonical_sha256':report['reconstruction_canonical_sha256'],
              'endpointBounds':[0]+[x['E_end_upper']['decimal_approx'] for x in report['step_bounds']],
              'times':times.tolist(),
              'reportUrl':f'comparison-reports/{ident}.html',
              'rawReportUrl':f'comparison-reports/certificate_{ident}.json'})
            print(json.dumps({'case':ident,'bound':report['final_error_upper']['decimal_approx'],
              'generation_ms':1e3*cases[-1]['generation']['medianSeconds'],
              'certificate_ms':1e3*cases[-1]['certificate']['medianSeconds']}),flush=True)
    import solver, certify as certmodule, w2_reference
    result={'setting':{'cutoff':3,'finalTime':.25,'viscosity':1,'modeCount':122,
       'initial':'W=(sin z,sin x,sin y)','domain':'2π-periodic 3D torus','normalization':'normalized spatial L2'},
       'cases':cases,'setup':setup,
       'protocol':{'methods':list(METHODS),'stepDenominators':list(DENOMINATORS),
        'generationTrials':GENERATION_TRIALS,'certificateTrials':CERTIFICATE_TRIALS,'setupTrials':SETUP_TRIALS,
        'time_function':'time.perf_counter',
        'generation':'warm in-memory coefficient generation, excluding setup, file I/O, diagnostics and certification; paper references evaluate all requested time nodes directly',
        'setup':'RK4 full-pair geometry or shared exact spatial W,F,C,H paper basis; measured separately, reusable for subsequent evaluations',
        'certificate':'certify.py wall time including NPZ read, rational reconstruction, exact full residual, report and reconstruction file writes',
        'context':'same shared server Python process; timings are local observations, not browser/industrial performance or asymptotic complexity',
        'reference_object':'exact rational projected piecewise-linear reconstruction from numerical endpoints for every method',
        'spatial_policy':'same 122 retained slots (N=3) for all; 829 full residual support modes; no active w2 mode truncated'},
       'environment':{'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform()},
       'sourceHashes':{'solver.py':sha(solver.__file__),'certify.py':sha(certmodule.__file__),
         'w2_reference.py':sha(w2_reference.__file__),'benchmark.py':sha(__file__)}}
    (HERE/'benchmark-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print('COMPLETE: benchmark-results.json',flush=True)

if __name__=='__main__':main()
